// *****************************************************************************
// Kristian Guillaumier, 2019, 2021
// Functions to create an offspring chromosomes by selecting parents from a
// population, and then performing crossover and mutation.
// *****************************************************************************

package genetic

import (
	"math/rand"

	"kguil.com/dfago/util"
)

// ---- CROSSOVER AND MUTATION -------------------------------------------------

// Returns the fittest chromosome in the population using tournament selection.
// Will panic if there are chromosomes in the population whose fitness is not
// evaluated or estimated.
func (ga genetic) tournament() chromosome {
	// Shuffle the population.
	rand.Shuffle(len(ga.population), func(i, j int) {
		ga.population[i], ga.population[j] = ga.population[j], ga.population[i]
	})

	// Assume that the first is the best.
	best := 0

	// Sanity check.
	if ga.population[best].dirty {
		panic("cannot select from a dirty population (1)")
	}

	// Check against the rest (start from index 1).
	for i := 1; i < ga.params.TournamentSize; i++ {
		// Make sure that the chromosome is not dirty.
		if ga.population[i].dirty {
			panic("cannot select from a dirty population (2)")
		}

		// Remember that the fitness is a penalty, so we want to minimise.
		if ga.population[i].fitness < ga.population[best].fitness {
			best = i
		}
	}

	// Done.
	return ga.population[best]
}

// Selects two parent chromosomes for crossover.
func (ga genetic) parents() (parent1, parent2 chromosome) {
	// Select the two parents.
	parent1 = ga.tournament()
	parent2 = ga.tournament()

	// Try to make sure that the two parents are distinct.
	attempts := 0

	for attempts < ga.params.MaxAttempts && parent1.mergesEqualTo(parent2) {
		parent2 = ga.tournament()
		attempts++
	}
	return
}

// Performs crossover on two parents and returns a new child. The fitness of the
// child chromosome is marked as dirty.
func (chrom chromosome) crossover(other chromosome) chromosome {
	// This is the actual crossover function.
	innerCrossover := func() chromosome {
		// Put all the merges from both parents in a slice. Don't worry about
		// duplicates because they will be dealt with later.
		merges := []util.IntPair{}
		merges = append(merges, chrom.merges...)
		merges = append(merges, other.merges...)

		// Shuffle the order of the merges to pick from.
		rand.Shuffle(len(merges), func(i, j int) {
			merges[i], merges[j] = merges[j], merges[i]
		})

		// Create the child chromosome.
		child := chromosome{
			merges:  make([]util.IntPair, 0, chrom.gen.params.ChromosomeLength),
			fitness: 0,
			dirty:   true,
			gen:     chrom.gen}

		// Create an initial partition and a snapshot.
		partition := chrom.gen.apta.StatePartition()
		snapshot := partition.Snapshot()

		for _, merge := range merges {
			// Skip any merges already in the chromosome.
			if snapshot.Find(merge.First) == snapshot.Find(merge.Second) {
				continue
			}

			// Append to the child if the merge is valid.
			if snapshot.DetMerge(merge.First, merge.Second) {
				// Accept the merge.
				child.merges = append(child.merges, merge)
				snapshot.CommitTo(&partition)
			} else {
				// Undo the merge.
				snapshot.RollbackFrom(partition)
			}

			// Check if the child chromosome is complete.
			if child.length() == child.gen.params.ChromosomeLength {
				break
			}
		}

		// Done.
		return child
	}

	// Create the child.
	child := innerCrossover()

	// Try to make sure that the child is not the same as either of the parents.
	attempts := 0
	maxAttempts := chrom.gen.params.MaxAttempts

	for attempts < maxAttempts && (child.mergesEqualTo(chrom) || child.mergesEqualTo(other)) {
		child = innerCrossover()
		attempts++
	}

	// Done.
	return child
}

// Mutates the chromosome. The fitness of the mutated chromosome is marked as
// dirty.
func (chrom *chromosome) mutate() {
	// This is the actual mutation. Will return true if we successfully mutated.
	innerMutate := func() bool {
		// Shuffle the merges in the chromosome.
		rand.Shuffle(len(chrom.merges), func(i, j int) {
			chrom.merges[i], chrom.merges[j] = chrom.merges[j], chrom.merges[i]
		})

		// Get the merge that will be deleted.
		deletedMerge := chrom.merges[len(chrom.merges)-1]

		// Remove the merge from the chromosome.
		chrom.merges = chrom.merges[:len(chrom.merges)-1]

		// Shuffle the order of the merges to pick from.
		chrom.gen.shuffleMergePool()

		// Create the starting partition.
		partition := chrom.partition()
		snapshot := partition.Snapshot()

		// Loop thru the merges.
		for _, merge := range chrom.gen.mergePool {
			// Skip the merge that we deleted.
			if merge.Equal(deletedMerge) {
				continue
			}

			// Skip any identity merges.
			if snapshot.Find(merge.First) == snapshot.Find(merge.Second) {
				continue
			}

			// If the merge is valid (non-blocking), accept it.
			if snapshot.DetMerge(merge.First, merge.Second) {
				// Append the merge to the chromosome to replace the one we deleted.
				chrom.merges = append(chrom.merges, merge)

				// Mark dirty.
				chrom.dirty = true

				// We're done. Tell the caller that the mutation was successful.
				return true
			}

			snapshot.RollbackFrom(partition)
		}

		// If we get here, it means that we haven't found a suitable replacement
		// for the merge we deleted. Put it back and fail.
		chrom.merges = append(chrom.merges, deletedMerge)
		return false
	}

	// Mutate.
	ok := innerMutate()
	attempts := 0
	maxAttempts := chrom.gen.params.MaxAttempts

	// Retry until we get a successful mutation.
	for attempts < maxAttempts && !ok {
		ok = innerMutate()
		attempts++
	}
}

// Creates a new chromosome by selecting two parents, performing crossover,
// and mutating the offspring by the mutation rate.
func (ga genetic) offspring() chromosome {
	parent1, parent2 := ga.parents()
	offspring := parent1.crossover(parent2)

	if rand.Float64() <= ga.params.MutationRate {
		offspring.mutate()
	}
	return offspring
}
