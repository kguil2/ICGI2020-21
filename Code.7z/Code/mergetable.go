// *****************************************************************************
// Kristian Guillaumier, 2017, 2021
// Represents a collection of merges in an APTA which reduce the number of
// states in the APTA by at least some value and have an EDSM score of at
// least some value.
// *****************************************************************************

package dfago

import (
	"fmt"
	"math/rand"
	"runtime"
	"time"

	"kguil.com/dfago/util"
)

// ---- TYPES ------------------------------------------------------------------

// AptaMergeTable is a collection of merges in an APTA which reduce the
// number of merges in the APTA by at least some value and have an EDSM score
// of at least some value.
type AptaMergeTable struct {
	MinimumReduction int             // The minimum number of states reduced for a merge to make it into the table.
	MinimumEDSM      int             // The minimum EDSM score for a merge to make it into the table.
	TotalMerges      int             // The total possible merges (valid or invalid) evaluated to create the table (i.e. the total possible merges in the APTA).
	Merges           []util.IntPair  // The merges in the table (merges having >= MinReduction and >= MinEDSM).
	MergesCC         util.IntPairSet // The colour-compatible merges in the table.
	Time             float64         // The time it took to build the table in seconds.
}

// ---- CONSTRUCTION -----------------------------------------------------------

// NewAptaMergeTable creates an APTA reduction table by selecting the merges
// in an APTA which have a minimum reduction and a minimum EDSM score.
//
// NOTE: By construction, all the merges in the table will have the form
//       (q1,q2) where the state index q1 is less than the state index q2.
func NewAptaMergeTable(apta DFA, minimumReduction, minimumEDSM int) AptaMergeTable {
	// Pass an empty colour map.
	return NewAptaMergeTableCC(apta, minimumReduction, minimumEDSM, AptaTargetMap{})
}

// NewAptaMergeTableCC creates an APTA reduction table by selecting the merges
// in an APTA which have a minimum reduction and a minimum EDSM score.
//
// NOTE: By construction, all the merges in the table will have the form
//       (q1,q2) where the state index q1 is less than the state index q2.
//
// NOTE: Optionally, we can pass an APTA colour map to determine which of the
//       merges in the table are colour-compatible or not. Provide an empty
//       APTA colour map if colour-compatibility is not available.
func NewAptaMergeTableCC(apta DFA, minimumReduction, minimumEDSM int, aptaColours AptaTargetMap) AptaMergeTable {
	// Start time.
	start := time.Now()

	// Number of states in APTA.
	numStates := apta.NumStates()

	// Prepare the result.
	result := AptaMergeTable{
		MinimumReduction: minimumReduction,
		MinimumEDSM:      minimumEDSM,
		TotalMerges:      (numStates*numStates - numStates) / 2,
		Merges:           []util.IntPair{},
		MergesCC:         util.IntPairSet{}}

	// Optimisation: we are merging in an APTA which is a tree. Each state
	// in the pair we are merging is therefore the root of a subtree. Since we
	// are merging in a tree, the number of states reduced **cannot** be greater
	// than the size of the smallest subtree. This optimisation saves a
	// significant amount of time and gets better the larger the APTA is.

	// Compute the size of every subtree in our APTA.
	subTreeSizes := apta.NumStatesInSubtrees()

	// The training set size is needed to compute EDSM score.
	trainingSize := apta.NumLabelled()

	// Prepare the initial partition.
	partition := apta.StatePartition()
	snapshot := partition.Snapshot()

	// Merge all distinct pairs of states in the APTA.
	for i := 0; i < numStates; i++ {
		for j := i + 1; j < numStates; j++ {
			// The number of states reduced in an APTA (tree) cannot be more
			// then the size of the smallest subtree which we are merging.
			// Only perform the merge if we *know* that it will have at least
			// the minimum reduction desired.
			upperBound := util.Min(subTreeSizes[i], subTreeSizes[j])

			if upperBound < minimumReduction {
				continue
			}

			// Perform the merge.
			if snapshot.DetMerge(i, j) {
				// Compute EDSM and reduction.
				edsm := trainingSize - snapshot.NumLabelledBlocks()
				reduction := partition.NumBlocks() - snapshot.NumBlocks()

				// Accept merge if it has at least reduction and EDSM.
				if reduction >= minimumReduction && edsm >= minimumEDSM {
					// Create the pair and add it to the list.
					pair := util.NewIntPair(i, j)
					result.Merges = append(result.Merges, pair)

					// Check if the merge is colour-compatible. We are
					// merging i with j which will end up in the same block.
					// So, to test colour-compatibility, we just need to see
					// whether the contents of the resulting block are
					// colour-compatible.
					if !aptaColours.Empty() && snapshot.BlockColourCompatible(i, aptaColours) {
						result.MergesCC.Add(pair)
					}
				}
			}

			// Rollback for the next merge.
			snapshot.RollbackFrom(partition)
		}
	}

	// End time.
	result.Time = time.Since(start).Seconds()

	// Done.
	return result
}

// ---- METHODS ----------------------------------------------------------------

// NumMerges returns the number of merges in the APTA merge table.
func (table AptaMergeTable) NumMerges() int {
	return len(table.Merges)
}

// NumCcMerges retuens the number of colour-compatible merges in the APTA
// merge table. Will return zero if the APTA merge table was created without
// colour information.
func (table AptaMergeTable) NumCcMerges() int {
	return len(table.MergesCC)
}

// Shuffle shuffles the order of the merges in the table.
func (table AptaMergeTable) Shuffle() {
	rand.Shuffle(len(table.Merges), func(i, j int) {
		table.Merges[i], table.Merges[j] = table.Merges[j], table.Merges[i]
	})
}

// RunDemoAptaMergeTable creates a number of merge tables for a specific
// problem instance configuration and performs an analysis on the contents
// of the tables (e.g. their average sizes, and so on...).
func RunDemoAptaMergeTable() {
	// Params.
	targetSize := 32
	trainingSize := 607
	minReduction := 25
	minEdsm := 1
	iterations := 256
	concurrency := runtime.NumCPU() * 8

	// -------------------------------------------------------------------------
	// The channel where we will receive our merge paths.
	type channelResult struct {
		totalMerges int
		merges      int
		ccMerges    int
		time        float64
	}

	producer := make(chan int, iterations)
	consumer := make(chan channelResult, iterations)

	// -------------------------------------------------------------------------
	// Spawn the workers.
	for i := 0; i < concurrency; i++ {
		go func() {
			for range producer {
				// Create problem instance.
				target, training, _ := NewAbbadingoInstance(targetSize, true, trainingSize, 0)
				apta := training.APTA(target.AlphabetSize())
				aptaColours := NewAptaTargetMap(apta, target)

				// Build the merge table.
				table := NewAptaMergeTableCC(apta, minReduction, minEdsm, aptaColours)

				consumer <- channelResult{
					totalMerges: table.TotalMerges,
					merges:      len(table.Merges),
					ccMerges:    len(table.MergesCC),
					time:        table.Time}
			}
		}()
	}

	// -------------------------------------------------------------------------
	// Create the jobs.
	for i := 0; i < iterations; i++ {
		producer <- i
	}

	// -------------------------------------------------------------------------
	// Aggregators.
	mmaTotalMerges := util.NewMinMaxAvg()
	mmaMerges := util.NewMinMaxAvg()
	mmaCcMerges := util.NewMinMaxAvg()

	// -------------------------------------------------------------------------
	// Consume the results.
	for i := 0; i < iterations; i++ {
		result := <-consumer

		fmt.Printf("Ready %d of %d in %.2fs\n", i+1, iterations, result.time)

		// Aggregate some stats.
		mmaTotalMerges.AddInt(result.totalMerges)
		mmaMerges.AddInt(result.merges)
		mmaCcMerges.AddInt(result.ccMerges)
	}

	// Close the channels.
	close(producer)
	close(consumer)

	// Print out results.
	fmt.Println()
	fmt.Println("------------------------")
	fmt.Println("ANALYSIS")
	fmt.Println("------------------------")
	fmt.Printf("Target Size: %d, Training Size: %d, MinReduction:%d, MinEDSM:%d, Iterations: %d\n", targetSize, trainingSize, minReduction, minEdsm, iterations)
	fmt.Println()
	fmt.Printf("[Total Merges]    min:%d max:%d, avg:%.2f\n", mmaTotalMerges.MinimumInt(), mmaTotalMerges.MaximumInt(), mmaTotalMerges.Average())
	fmt.Printf("[Table Merges]    min:%d max:%d, avg:%.2f\n", mmaMerges.MinimumInt(), mmaMerges.MaximumInt(), mmaMerges.Average())
	fmt.Printf("[CC Table Merges] min:%d max:%d, avg:%.2f\n", mmaCcMerges.MinimumInt(), mmaCcMerges.MaximumInt(), mmaCcMerges.Average())
	fmt.Println()
}
