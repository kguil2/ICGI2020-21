// *****************************************************************************
// Kristian Guillaumier, 2017, 2020
// Represents a DFA.
// *****************************************************************************

package dfago

import (
	"bytes"
	"fmt"
	"sort"
	"strings"
	"time"

	"kguil.com/dfago/util"
)

// ---- TYPES ------------------------------------------------------------------

// DFA is a deterministic automaton.
type DFA struct {
	StartingState int     // The index of the starting state of the DFA.
	States        []State // The states in the DFA.
	Alphabet      []int   // A slice containing the ordered alphabet of the DFA.
	depth         int     // The depth of the DFA.
	dirty         bool    // Flag to tell us whether the depth and order of the DFA and its states is computed.
}

// DFAInfo is a collection of information about a DFA.
type DFAInfo struct {
	NumStates                  int
	NumAcceptingStates         int
	NumRejectingStates         int
	NumLabelledStates          int
	NumUnlabelledStates        int
	ProportionAcceptingStates  float64
	ProportionRejectingStates  float64
	ProportionLabelledStates   float64
	ProportionUnlabelledStates float64
	NumLoops                   int
	NumTransitions             int
	NumLeaves                  int
	NumAcceptingLeaves         int
	NumRejectingLeaves         int
	NumLabelledLeaves          int
	NumUnlabelledLeaves        int
	ProportionLeaves           float64
	ProportionAcceptingLeaves  float64
	ProportionRejectingLeaves  float64
	ProportionLabelledLeaves   float64
	ProportionUnlabelledLeaves float64
	Depth                      int
}

// ---- CONSTRUCTION -----------------------------------------------------------

// NewDFA creates an empty DFA having an alphabet size.
func NewDFA(alphabetSize int) (dfa DFA) {
	return NewSizedDFA(alphabetSize, 0)
}

// NewSizedDFA creates an empty DFA having an alphabet size. An initial
// capacity parameter is used to preallocate space for states.
func NewSizedDFA(alphabetSize, initialCapacity int) (dfa DFA) {
	// Check.
	if alphabetSize < 1 {
		panic("alphabet size should be at least 2")
	}

	if initialCapacity < 0 {
		panic("initial capacity should be at least 0")
	}

	// Create the DFA.
	dfa = DFA{
		StartingState: 0,
		States:        make([]State, 0, initialCapacity),
		Alphabet:      make([]int, alphabetSize),
		depth:         0,
		dirty:         false}

	// The alphabet of the DFA will be an ordered list of symbols [0..n).
	for i := 0; i < alphabetSize; i++ {
		dfa.Alphabet[i] = i
	}
	return
}

// ---- COUNTING FUNCTIONS -----------------------------------------------------

// NumStates returns the number of states in the DFA.
func (dfa DFA) NumStates() int {
	return len(dfa.States)
}

// NumAccepting returns the number of accepting states in the DFA.
func (dfa DFA) NumAccepting() (count int) {
	for _, state := range dfa.States {
		if state.Accepting() {
			count++
		}
	}
	return
}

// NumRejecting returns the number of rejecting states in the DFA.
func (dfa DFA) NumRejecting() (count int) {
	for _, state := range dfa.States {
		if state.Rejecting() {
			count++
		}
	}
	return
}

// NumLabelled returns the number of labelled (accepting or
// rejecting) states in the DFA.
func (dfa DFA) NumLabelled() (count int) {
	for _, state := range dfa.States {
		if state.Labelled() {
			count++
		}
	}
	return
}

// NumUnlabelled returns the number of unlabelled states in the DFA.
func (dfa DFA) NumUnlabelled() (count int) {
	for _, state := range dfa.States {
		if state.Unlabelled() {
			count++
		}
	}
	return
}

// NumLeaves returns the number of left states in a DFA. A leaf is a state which
// does not have any outgoing transitions (useful in PTAs or APTAs).
func (dfa DFA) NumLeaves() (count int) {
	for _, state := range dfa.States {
		if state.Leaf() {
			count++
		}
	}
	return
}

// NumLoops returns the number of loop transitions in the DFA. A loop is a
// transition from a state to itself.
func (dfa DFA) NumLoops() (count int) {
	// Examine all transitions.
	for i := range dfa.States {
		for symbol := range dfa.Alphabet {
			if next := dfa.States[i].Next[symbol]; next == i {
				count++
			}
		}
	}
	return
}

// NumStatesInSubtrees returns a slice equal in length to the number of states
// in the DFA where:
// index: 	is a state index.
// value: 	the value is the number of states in the subtree rooted at that
//			state (including itself).
//
// Will panic if the calling DFA is not a tree or has unreachable states.
func (dfa DFA) NumStatesInSubtrees() (result []int) {
	// Prepare the result.
	result = make([]int, len(dfa.States))

	// We're gonna do a DFS, so keep a visited set.
	visited := util.IntSet{}

	// This is our recursive DFS.
	var numStates func(stateIndex int)

	numStates = func(stateIndex int) {
		result[stateIndex] = 1
		visited.Add(stateIndex)

		for _, next := range dfa.States[stateIndex].Next {
			if next >= 0 {
				// Check visited.
				if visited.Contains(next) {
					panic("the DFA contains cycles")
				}

				// DFS.
				numStates(next)

				// Update parent using children.
				result[stateIndex] += result[next]
			}
		}
	}

	// Do a recursive DFS.
	numStates(dfa.StartingState)

	// If there are unexplored vertices, then this is not a tree (i.e. the
	// DFA is disconnected).
	if len(visited) != len(dfa.States) {
		panic("the DFA contains unreachable states")
	}
	return
}

// NumTransitions returns the number of transitions in the DFA.
func (dfa DFA) NumTransitions() (count int) {
	for _, state := range dfa.States {
		count += state.OutDegree()
	}
	return count
}

// NumTransitionsForSymbol returns the number of transitions in the DFA
// that have a symbol.
func (dfa DFA) NumTransitionsForSymbol(symbol int) (count int) {
	for _, state := range dfa.States {
		if state.Next[symbol] >= 0 {
			count++
		}
	}
	return count
}

// Info returns information about this this DFA. This is more efficient than
// calling many different NumXXX() functions.
func (dfa *DFA) Info() DFAInfo {
	// Prepare the result.
	result := DFAInfo{NumStates: len(dfa.States), Depth: dfa.Depth()}

	// Loop thru all the states and start counting.
	for _, state := range dfa.States {
		switch state.Label {
		case Accepting:
			result.NumAcceptingStates++
			result.NumLabelledStates++

			if state.Leaf() {
				result.NumLeaves++
				result.NumAcceptingLeaves++
				result.NumLabelledLeaves++
			}

		case Rejecting:
			result.NumRejectingStates++
			result.NumLabelledStates++

			if state.Leaf() {
				result.NumLeaves++
				result.NumRejectingLeaves++
				result.NumLabelledLeaves++
			}

		case Unlabelled:
			result.NumUnlabelledStates++

			if state.Leaf() {
				result.NumLeaves++
				result.NumUnlabelledLeaves++
			}

		default:
			panic("a state in the DFA has an unknown state label")
		}
	}

	// Count the loops and transitions.
	for i := range dfa.States {
		for symbol := range dfa.Alphabet {
			if next := dfa.States[i].Next[symbol]; next >= 0 {
				if next == i {
					result.NumLoops++
				}
				result.NumTransitions++
			}
		}
	}

	// State proportions.
	result.ProportionAcceptingStates = float64(result.NumAcceptingStates) / float64(result.NumStates)
	result.ProportionRejectingStates = float64(result.NumRejectingStates) / float64(result.NumStates)
	result.ProportionLabelledStates = float64(result.NumLabelledStates) / float64(result.NumStates)
	result.ProportionUnlabelledStates = float64(result.NumUnlabelledStates) / float64(result.NumStates)
	result.ProportionLeaves = float64(result.NumLeaves) / float64(result.NumStates)

	// Leaf proportions.
	result.ProportionAcceptingLeaves = float64(result.NumAcceptingLeaves) / float64(result.NumLeaves)
	result.ProportionRejectingLeaves = float64(result.NumRejectingLeaves) / float64(result.NumLeaves)
	result.ProportionLabelledLeaves = float64(result.NumLabelledLeaves) / float64(result.NumLeaves)
	result.ProportionUnlabelledLeaves = float64(result.NumUnlabelledLeaves) / float64(result.NumLeaves)

	// Done.
	return result
}

// ---- ADD STATES AND TRANSITIONS ---------------------------------------------

// AddState adds a state to the DFA and returns its index.
func (dfa *DFA) AddState(label StateLabel) int {
	// Create the state.
	state := State{Label: label, Next: make([]int, len(dfa.Alphabet))}

	// Set all the outgoing transitions to 'null'.
	for i := range state.Next {
		state.Next[i] = -1
	}

	// Add the state.
	dfa.States = append(dfa.States, state)

	// The depth and order are now dirty.
	dfa.dirty = true

	// Done.
	return len(dfa.States) - 1
}

// AddStates adds a number of states to the DFA.
func (dfa *DFA) AddStates(count int, label StateLabel) {
	// Add the desired number of states.
	for i := 0; i < count; i++ {
		dfa.AddState(label)
	}
}

// DeleteState deletes a state from the DFA. Will panic if we delete the
// starting state.
func (dfa *DFA) DeleteState(stateIndex int) {
	// Check.
	if dfa.StartingState == stateIndex {
		panic("you cannot delete the starting state (change it first)")
	}

	// Delete the state.
	dfa.States = append(dfa.States[:stateIndex], dfa.States[stateIndex+1:]...)

	// Correct the starting state if necessary.
	if dfa.StartingState > stateIndex {
		dfa.StartingState--
	}

	// Now correct all the transistions.
	for symbol := range dfa.Alphabet {
		for i := range dfa.States {
			if dfa.States[i].Next[symbol] == stateIndex {
				// We deleted the transition for that symbol.
				dfa.States[i].Next[symbol] = -1
			} else if dfa.States[i].Next[symbol] > stateIndex {
				// All the state indices greater than the state index we deleted
				// have to be shifted back by 1.
				dfa.States[i].Next[symbol]--
			}
		}
	}

	// The depth and order are now dirty.
	dfa.dirty = true
}

// DeleteStates deletes all the states at the specified indices in the DFA.
func (dfa *DFA) DeleteStates(stateIndices []int) {
	// This is tricky because each time one of the states in stateIndices is
	// deleted, the remaining states in list can be invalidated.
	for i, v := range stateIndices {
		// Remember the index to delete.
		index := v

		// Delete it.
		dfa.DeleteState(index)

		// Repair remaining indices to delete.
		for j := i + 1; j < len(stateIndices); j++ {
			if stateIndices[j] > index {
				// All the state indices greater than the state index deleted
				// have to be shifted back by 1.
				stateIndices[j]--
			}
		}
	}
}

// AddTransition adds a transition to the DFA. Will panic if there is already an
// outgoing transition from the given state for the symbol (the transition
// would make the automaton non-deterministic).
func (dfa *DFA) AddTransition(fromStateIndex, toStateIndex, symbol int) {
	// Check if the transition already exists.
	if dfa.States[fromStateIndex].Next[symbol] >= 0 {
		panic("a transition for the given state and symbol already exists (delete it first)")
	}

	// Add the transition.
	dfa.States[fromStateIndex].Next[symbol] = toStateIndex

	// The depth and order are now dirty.
	dfa.dirty = true
}

// DeleteTransition deletes an outgoing transition from a state for a symbol.
func (dfa *DFA) DeleteTransition(fromStateIndex, symbol int) {
	// Delete.
	dfa.States[fromStateIndex].Next[symbol] = -1

	// The depth and order are now dirty.
	dfa.dirty = true
}

// ---- GET STATES AND TRANSITIONS ---------------------------------------------

// AllStates returns a slice containing the indices of the states in the DFA.
func (dfa DFA) AllStates() (result []int) {
	// Initialise to the correct size.
	result = make([]int, len(dfa.States))

	// Put in the indices.
	for i := range dfa.States {
		result[i] = i
	}
	return
}

// AcceptingStates returns a slice containing the indices of the accepting
// states in the DFA.
func (dfa DFA) AcceptingStates() (result []int) {
	// Initialise the result.
	result = []int{}

	// Put in the indices.
	for i := range dfa.States {
		if dfa.States[i].Accepting() {
			result = append(result, i)
		}
	}
	return
}

// OrderedStates returns a slice containing the indices of the states in the
// DFA in canonical order.
func (dfa *DFA) OrderedStates() (result []int) {
	// Recompute the depth and order if needed.
	dfa.computeDepthAndOrderIfNeeded()

	// Get all the states.
	result = dfa.AllStates()

	// Sort the states.
	sort.Slice(result, func(i int, j int) bool {
		return dfa.States[result[i]].order < dfa.States[result[j]].order
	})
	return
}

// PairsOfStates returns all the distinct, unordered pairs of states in
// this DFA.
func (dfa DFA) PairsOfStates() (pairs []util.IntPair) {
	// We know the number of pairs that will be generated.
	numStates := len(dfa.States)
	numPairs := (numStates*numStates - numStates) / 2

	// Prepare the result.
	pairs = make([]util.IntPair, numPairs)
	index := 0

	// Create all pairs.
	for i := 0; i < numStates; i++ {
		for j := i + 1; j < numStates; j++ {
			pairs[index] = util.IntPair{First: i, Second: j}
			index++
		}
	}
	return
}

// Transitions returns all the transitions in the DFA.
func (dfa DFA) Transitions() (transitions []Transition) {
	// Prepare the result.
	transitions = []Transition{}

	// Get them all.
	for symbol := range dfa.Alphabet {
		for i := range dfa.States {
			if next := dfa.States[i].Next[symbol]; next >= 0 {
				transitions = append(transitions, Transition{From: i, To: next, Symbol: symbol})
			}
		}
	}
	return
}

// Succ returns the successors of a state. The successors are a map where
// the key is the alphabet symbol and the value is the next state in the DFA
// for that symbol. Since this returns a map, the order of the elements is
// undefined and not necessarily in canonical order (of symbols).
func (dfa DFA) Succ(stateIndex int) (successors map[int]int) {
	successors = make(map[int]int)

	for symbol := range dfa.Alphabet {
		if dfa.States[stateIndex].Next[symbol] >= 0 {
			successors[symbol] = dfa.States[stateIndex].Next[symbol]
		}
	}
	return
}

// ---- DEPTH AND ORDER --------------------------------------------------------

// Depth returns the depth of the DFA.
func (dfa *DFA) Depth() int {
	// Recompute the depth if needed.
	dfa.computeDepthAndOrderIfNeeded()

	// Done.
	return dfa.depth
}

// Returns the canonical order of a state in the DFA
func (dfa *DFA) StateOrder(stateIndex int) int {
	// Recompute the orders if needed.
	dfa.computeDepthAndOrderIfNeeded()

	// Done.
	return dfa.States[stateIndex].order
}

// Returns the depth of a state in the DFA
func (dfa *DFA) StateDepth(stateIndex int) int {
	// Recompute the orders if needed.
	dfa.computeDepthAndOrderIfNeeded()

	// Done.
	return dfa.States[stateIndex].depth
}

// Called internally to compute depth and state order if needed.
func (dfa *DFA) computeDepthAndOrderIfNeeded() {
	// Check if needed.
	if !dfa.dirty {
		return
	}

	// Prepare our queue and visited set.
	queue := util.NewIntQueueWithValueAndCapacity(dfa.StartingState, len(dfa.States))
	visited := util.NewIntSetWithValueAndCapacity(dfa.StartingState, len(dfa.States))
	currentOrder := 0
	dfa.depth = 0

	// Do a breadth-first traversal.
	for queue.NotEmpty() {
		// Dequeue.
		currentIndex, _ := queue.Dequeue()
		currentState := &dfa.States[currentIndex]

		// Update the depth of the DFA.
		dfa.depth = util.Max(currentState.depth, dfa.depth)
		currentState.order = currentOrder
		currentOrder++

		// Expand all children in canonical order.
		for symbol := range dfa.Alphabet {
			if next := currentState.Next[symbol]; next >= 0 {
				if !visited.Contains(next) {
					dfa.States[next].depth = currentState.depth + 1
					visited.Add(next)
					queue.Enqueue(next)
				}
			}
		}
	}

	// Check that we visited everyone.
	if len(visited) != len(dfa.States) {
		panic("the DFA contains unreachable states")
	}

	// Flag as clean.
	dfa.dirty = false
}

// ---- OTHER METHODS ----------------------------------------------------------

// AlphabetSize returns the size of the alphabet of this DFA.
func (dfa DFA) AlphabetSize() int {
	return len(dfa.Alphabet)
}

// Complete determines whether every state has an outgoing transition for
// every symbol.
func (dfa DFA) Complete() bool {
	for _, state := range dfa.States {
		if state.OutDegree() != len(dfa.Alphabet) {
			return false
		}
	}
	return true
}

// Tree determines whether this DFA is a tree (e.g. a PTA or an APTA).
//
// TODO: this is wrong. This is checking that the DFA is a DAG not a tree.
//
func (dfa DFA) Tree() bool {
	// We'll use a DFS (stack) with a visited set to see if we encounter
	// a state twice. Push the starting state.
	visited := util.IntSet{}
	stack := util.IntStack{dfa.StartingState}

	// Do a DFS.
	for !stack.Empty() {
		// Get the state.
		node, _ := stack.Pop()

		// Mark visited.
		visited.Add(node)

		// Expand children.
		for symbol := range dfa.Alphabet {
			if next := dfa.States[node].Next[symbol]; next >= 0 {
				if visited.Contains(next) {
					// Child already visited. Definitely not a tree.
					return false
				}

				// Not visited.
				stack.Push(next)
			}
		}
	}

	// If there are unexplored vertices, then this is not a tree (i.e. the
	// DFA is disconnected).
	return visited.Count() == len(dfa.States)
}

// Clone creates an exact copy of this instance.
func (dfa DFA) Clone() DFA {
	// Prepare the result.
	result := DFA{
		StartingState: dfa.StartingState,
		States:        make([]State, len(dfa.States)),
		Alphabet:      make([]int, len(dfa.Alphabet)),
		dirty:         dfa.dirty,
		depth:         dfa.depth}

	// Clone the alphabet.
	copy(result.Alphabet, dfa.Alphabet)

	// Clone the states.
	for i := range dfa.States {
		result.States[i] = dfa.States[i].Clone()
	}

	// Done.
	return result
}

// Equal determines if two DFAs are deeply equal to each other.
func (dfa DFA) Equal(other DFA) bool {
	if dfa.StartingState != other.StartingState {
		return false
	}

	if dfa.AlphabetSize() != other.AlphabetSize() {
		return false
	}

	if dfa.dirty != other.dirty {
		return false
	}

	if dfa.depth != other.depth {
		return false
	}

	if len(dfa.States) != len(other.States) {
		return false
	}

	for i, state := range dfa.States {
		if !state.Equal(other.States[i]) {
			return false
		}
	}

	return true
}

// SameAs determines if one DFA is the same as another one. This ignores
// the ordering of the states in the States slice and treats all unlabelled
// states in both DFAs as rejecting states. In other words, they are the same
// DFA that recognise the same language but thay are not deeply equal.
func (dfa *DFA) SameAs(other *DFA) bool {
	// TODO: This is stupid slow. Do something about it.

	// Get linear representations (which ignores state orderings) and treat
	// all unlabelled states as rejecting.
	l1 := strings.ReplaceAll(dfa.LinearRepresentation(), "?", "-")
	l2 := strings.ReplaceAll(other.LinearRepresentation(), "?", "-")

	// Done.
	return l1 == l2
}

// LinearRepresentation returns a string representation of the DFA. If two DFAs
// are the same but have different state indices, their linear representation
// will be the same because in the result returned, the states are ordered
// canonically rather than by insert order.
func (dfa *DFA) LinearRepresentation() string {
	// Get the states and symbols in order.
	states := dfa.OrderedStates()

	// Construct the sting in a buffer.
	var buffer bytes.Buffer

	// Open the string.
	buffer.WriteString("(")

	// Write all the states.
	for _, stateIndex := range states {
		// States are numbered using their order.
		stateOrder := dfa.States[stateIndex].order

		// Open the state substring, write the state number and type.
		switch dfa.States[stateIndex].Label {
		case Accepting:
			buffer.WriteString(fmt.Sprintf("(%d+", stateOrder))
		case Rejecting:
			buffer.WriteString(fmt.Sprintf("(%d-", stateOrder))
		case Unlabelled:
			buffer.WriteString(fmt.Sprintf("(%d?", stateOrder))
		default:
			panic(fmt.Sprintf("state with index %d has an unrecognised type", stateIndex))
		}

		// Loop thru all symbols.
		for symbol := range dfa.Alphabet {
			if next := dfa.States[stateIndex].Next[symbol]; next >= 0 {
				nextStateOrder := dfa.States[next].order
				buffer.WriteString(fmt.Sprintf("(%d,%d)", symbol, nextStateOrder))
			}
		}

		// Close the state string.
		buffer.WriteString(")")
	}

	// Close the linear string.
	buffer.WriteString(")")

	// Done.
	return buffer.String()
}

// ---- PARSE SAMPLES  ---------------------------------------------------------

// ParseToState parses a sample in the DFA, and returns the index of the state
// reached by the sample. Will return false if the sample cannot be entirely
// consumed by the DFA because the DFA is not complete. In this case, the state
// index returned is undefined.
func (dfa DFA) ParseToState(sample Sample) (int, bool) {
	// If the sample is an empty string, then it parses to the starting state.
	if len(sample) == 0 {
		return dfa.StartingState, true
	}

	// Parse.
	current := dfa.StartingState

	// Visit every state by following the sample.
	for _, symbol := range sample {
		// See where this symbol takes us.
		if next := dfa.States[current].Next[symbol]; next >= 0 {
			current = next
		} else {
			// The DFA cannot consume the sample because it is not complete.
			return -1, false
		}
	}

	// We're done.
	return current, true
}

// Parse parses a sample and tells us whether the string is accepted or rejected
// by the DFA. The sample is accepted only if it reaches an accepting state.
// The sample will be rejected if it cannot be consumed by the DFA (because the
// DFA is not complete) or it reaches a rejecting or unlabelled state.
func (dfa DFA) Parse(sample Sample) bool {
	// Parse to the state reached.
	state, ok := dfa.ParseToState(sample)

	// If the string is unparsable, then it is rejected.
	if !ok {
		return false
	}

	// Otherwise, the string is only accepted if we reach an accepting state.
	return dfa.States[state].Label == Accepting
}

// ParseBinaryString parses a binary strind defined over the alphabet {a,b} of
// {0,1} and tells us whether the string is accepted or rejected by the DFA.
// The sample is accepted only if it reaches an accepting state. The sample
// will be rejected if it cannot be consumed by the DFA (because the DFA is not
// complete) or it reaches a rejecting or unlabelled state.
func (dfa DFA) ParseBinaryString(str string) bool {
	return dfa.Parse(BinaryStringToSample(str))
}

// StateVisitor calls a callback function for each state traversed when
// parsing a given sample. The callback function tells us:
// * stateIndex: 		Each state hit by the symbol sequence including lambda.
// * prevStateIndex:	The previous state that lead us to 'stateIndex'.
// * prevSymbol: 		The predecessor symbol that lead us to 'stateIndex'.
//
// NOTE: prevStateIndex and prevSymbol will be (-1,-1) if the state visited is
// the starting state (because it does not have a predecessor).
func (dfa DFA) StateVisitor(sample Sample, callback func(stateIndex, prevStateIndex, prevSymbol int)) {
	// If the DFA is empty, there's nothing to do.
	if len(dfa.States) == 0 {
		return
	}

	// We start at the starting state.
	callback(dfa.StartingState, -1, -1)

	// Parse.
	current := dfa.StartingState

	for _, symbol := range sample {
		if next := dfa.States[current].Next[symbol]; next >= 0 {
			callback(next, current, symbol)
			current = next
		}
	}
}

// ---- SERIALISE AND DESERIALISE  ---------------------------------------------

// Serialise converts this instance to an object that can be serialised.
func (dfa DFA) Serialise() SerialiseObject {
	// Prepare the states.
	states := make([]map[string]interface{}, len(dfa.States))

	for i, state := range dfa.States {
		// Add to the node to the list.
		states[i] = map[string]interface{}{
			"Label": state.Label,
			"Next":  state.Next,
			"depth": state.depth,
			"order": state.order}
	}

	// Done.
	return SerialiseObject{
		"docType":       "DfaGo/DFA",
		"version":       1.0,
		"dateCreated":   time.Now().Format(time.RFC3339),
		"StartingState": dfa.StartingState,
		"States":        states,
		"Alphabet":      dfa.Alphabet,
		"dirty":         dfa.dirty,
		"depth":         dfa.depth}
}

// Deserialises a serialised object to an instance.
func DeserialiseDFA(data DeserialiseObject) DFA {
	// Validate the doc type and version.
	if expected, got := 1.0, data["version"].(float64); expected != got {
		panic(fmt.Sprintf("JSON file has an unsupported version, expected:%f, got:%f", expected, got))
	}

	if expected, got := "DfaGo/DFA", data["docType"].(string); expected != got {
		panic(fmt.Sprintf("JSON file has an unsupported doc type, expected:%s, got:%s", expected, got))
	}

	// Start building the result.
	result := DFA{
		StartingState: int(data["StartingState"].(float64)),
		dirty:         data["dirty"].(bool),
		depth:         int(data["depth"].(float64))}

	// Import the states.
	states := data["States"].([]interface{})
	result.States = make([]State, len(states))

	for i, v := range states {
		state := v.(map[string]interface{})

		result.States[i] = State{
			Label: StateLabel(state["Label"].(float64)),
			depth: int(state["depth"].(float64)),
			order: int(state["order"].(float64))}

		// Read the transitions.
		next := state["Next"].([]interface{})
		result.States[i].Next = make([]int, len(next))

		for j, w := range next {
			result.States[i].Next[j] = int(w.(float64))
		}
	}

	// Import the alphabet.
	alphabet := data["Alphabet"].([]interface{})
	result.Alphabet = make([]int, len(alphabet))

	for i, v := range alphabet {
		result.Alphabet[i] = int(v.(float64))
	}

	// Done.
	return result
}
