// *****************************************************************************
// Kristian Guillaumier, 2017, 2020
// Represents a state in a DFA.
// *****************************************************************************

package dfago

// ---- TYPES ------------------------------------------------------------------

// State is a state in a DFA.
type State struct {
	Label StateLabel // Label of the state.
	Next  []int      // Index is the alphabet symbol. Value is index of adjacent state (-1 if there is no transition for symbol).

	// Internal.
	depth int // The depth of the state in the DFA (only if DFA is not dirty).
	order int // The canonical order of the state in the DFA (only if DFA is not dirty).
}

// StateLabel defines the variable type of a state label - accepting,
// rejecting, unlabelled.
type StateLabel int8

const (
	Accepting  StateLabel = 0
	Rejecting  StateLabel = 1
	Unlabelled StateLabel = 2
)

// ---- METHODS ----------------------------------------------------------------

// Accepting determines whether the state is an accepting state.
func (state State) Accepting() bool {
	return state.Label == Accepting
}

// Rejecting determines whether the state is an rejecting state.
func (state State) Rejecting() bool {
	return state.Label == Rejecting
}

// Labelled determines whether the state is accepting or rejecting.
func (state State) Labelled() bool {
	return state.Label == Accepting || state.Label == Rejecting
}

// Unlabelled determines whether the state is an unlabelled state.
func (state State) Unlabelled() bool {
	return state.Label == Unlabelled
}

// Leaf determines whether a state has no outgoing transitions (useful in
// PTAs or APTAs).
func (state State) Leaf() bool {
	return state.OutDegree() == 0
}

// OutDegree computes the outdegree of the state.
func (state State) OutDegree() (count int) {
	for _, v := range state.Next {
		if v >= 0 {
			count++
		}
	}
	return
}

// Clone creates an exact copy of this instance.
func (state State) Clone() State {
	result := State{
		Label: state.Label,
		Next:  make([]int, len(state.Next)),
		depth: state.depth,
		order: state.order}

	copy(result.Next, state.Next)

	// Done.
	return result
}

// Equal determines whether this state is equal to another.
func (state State) Equal(other State) bool {
	if state.Label != other.Label {
		return false
	}

	if state.depth != other.depth {
		return false
	}

	if state.order != other.order {
		return false
	}

	if len(state.Next) != len(other.Next) {
		return false
	}

	for i := range state.Next {
		if state.Next[i] != other.Next[i] {
			return false
		}
	}

	return true
}
