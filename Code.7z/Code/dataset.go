// *****************************************************************************
// Kristian Guillaumier, 2017, 2020
// Represents a set of positive and negative samples.
// *****************************************************************************

package dfago

import (
	"fmt"
	"math"
	"time"

	"kguil.com/dfago/util"
)

// ---- TYPES ------------------------------------------------------------------

// Dataset is a set of positive and negative samples.
type Dataset struct {
	// Positive is a slice of samples. A sample is a slice/sequence of
	// symbols (ints).
	Positive []Sample

	// Negative is a slice of samples. A sample is a slice/sequence of
	// symbols (ints).
	Negative []Sample
}

// ---- CONSTRUCTION -----------------------------------------------------------

// NewDataset creates an empty dataset.
func NewDataset() Dataset {
	return Dataset{
		Positive: []Sample{},
		Negative: []Sample{}}
}

// NewDatasetWithCapacity creates an empty dataset with an initial capacity to
// store positive and negative samples.
func NewDatasetWithCapacity(positiveSamples, negativeSamples int) Dataset {
	return Dataset{
		Positive: make([]Sample, 0, positiveSamples),
		Negative: make([]Sample, 0, negativeSamples)}
}

// ---- METHODS ----------------------------------------------------------------

// AddPositive adds a positive sample to the dataset. It is the callers
// responsibility to ensure that there are no duplicates.
func (set *Dataset) AddPositive(sample Sample) {
	(*set).Positive = append(set.Positive, sample)
}

// AddNegative adds a negative sample to the dataset. It is the callers
// responsibility to ensure that there are no duplicates.
func (set *Dataset) AddNegative(sample Sample) {
	(*set).Negative = append(set.Negative, sample)
}

// NumPositive returns the number of positive samples in the dataset.
func (set Dataset) NumPositive() int {
	return len(set.Positive)
}

// NumNegative returns the number of positive samples in the dataset.
func (set Dataset) NumNegative() int {
	return len(set.Negative)
}

// Size returns the number of positive and negative samples in the dataset.
func (set Dataset) Size() int {
	return len(set.Positive) + len(set.Negative)
}

// ProportionPositive returns the proportion of positive strings in the set.
func (set Dataset) ProportionPositive() float64 {
	return float64(set.NumPositive()) / float64(set.Size())
}

// ProportionNegative returns the proportion of negative strings in the set.
func (set Dataset) ProportionNegative() float64 {
	return float64(set.NumNegative()) / float64(set.Size())
}

// Balanced checks whether the proportion of of positive strings is balanced
// with respect to the proportion of negative strings. The set is balanced if
// they are within a tolerance. For example, if proportionDifference=0.1 then
// there cannot be more than a +/- 10% difference in number of positive or negative strings.
func (set Dataset) Balanced(proportionDifference float64) bool {
	return math.Abs(set.ProportionPositive()-set.ProportionNegative()) <= proportionDifference
}

// MinMaxAvgLengths returns the minimum, maximum, and average lengths of the
// samples in the training set.
func (set Dataset) MinMaxAvgLengths() (min, max int, avg float64) {
	// Prepare the utility.
	mma := util.NewMinMaxAvg()

	// Positive.
	for _, sample := range set.Positive {
		mma.AddInt(len(sample))
	}

	// Negative.
	for _, sample := range set.Negative {
		mma.AddInt(len(sample))
	}

	// Done.
	min = mma.MinimumInt()
	max = mma.MaximumInt()
	avg = mma.Average()
	return
}

// Equal determines whether two datasets are equal.
func (set Dataset) Equal(other Dataset) bool {
	if len(set.Positive) != len(other.Positive) {
		return false
	}

	if len(set.Negative) != len(other.Negative) {
		return false
	}

	// Check positive.
	for i := range set.Positive {
		if !set.Positive[i].Equal(other.Positive[i]) {
			return false
		}
	}

	// Check negative.
	for i := range set.Positive {
		if !set.Negative[i].Equal(other.Negative[i]) {
			return false
		}
	}

	// Done.
	return true
}

// ---- SERIALISE AND DESERIALISE  ---------------------------------------------

// Serialise converts this instance to an object that can be serialised.
func (set Dataset) Serialise() SerialiseObject {
	return map[string]interface{}{
		"docType":     "DfaGo/Dataset",
		"version":     1.0,
		"dateCreated": time.Now().Format(time.RFC3339),
		"positive":    set.Positive,
		"negative":    set.Negative}
}

// Deserialises a serialised object to an instance.
func DeserialiseDataSet(data DeserialiseObject) Dataset {
	// Validate the doc type and version.
	if expected, got := 1.0, data["version"].(float64); expected != got {
		panic(fmt.Sprintf("JSON file has an unsupported version, expected:%f, got:%f", expected, got))
	}

	if expected, got := "DfaGo/Dataset", data["docType"].(string); expected != got {
		panic(fmt.Sprintf("JSON file has an unsupported doc type, expected:%s, got:%s", expected, got))
	}

	// Extract the positive and negative slices from the map.
	positive := data["positive"].([]interface{})
	negative := data["negative"].([]interface{})

	// Prepare the result.
	result := Dataset{}
	result.Positive = make([]Sample, len(positive))
	result.Negative = make([]Sample, len(negative))

	// Insert the positive samples.
	for i, v := range positive {
		vSample := v.(([]interface{}))
		sample := make(Sample, len(vSample))

		for j, symbol := range vSample {
			sample[j] = int(symbol.(float64))
		}

		result.Positive[i] = sample
	}

	// Insert the negative samples.
	for i, v := range negative {
		vSample := v.(([]interface{}))
		sample := make(Sample, len(vSample))

		for j, symbol := range vSample {
			sample[j] = int(symbol.(float64))
		}

		result.Negative[i] = sample
	}

	// Done.
	return result
}
