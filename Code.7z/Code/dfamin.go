// *****************************************************************************
// Kristian Guillaumier, 2017, 2020
// Functions to perform Hopcroft minimisation on a DFA.
//
// Algorithm is adapted from "An Introduction to Formal Languages and Automata"
// by Peter Linz.
// *****************************************************************************

package dfago

import (
	"kguil.com/dfago/util"
)

// Minimise returns a minimised DFA. The original DFA is not affected.
func (dfa DFA) Minimise() DFA {
	// The DFA should only have accepting or unlabelled states (i.e. this is
	// a 'normal' DFA without rejecting states).
	if dfa.NumRejecting() != 0 {
		panic("the DFA to minimise should not contain any rejecting states")
	}

	// Work in a copy of the DFA.
	workingDFA := dfa.Clone()

	// Remove unreachable states from the DFA.
	workingDFA.DeleteUnreachableStates()

	// Find all indistinguishable states and merge them.
	partition := workingDFA.StatePartition()
	indistinguishablePairs := workingDFA.IndistinguishablePairs()

	for pair := range indistinguishablePairs {
		partition.Union(pair.First, pair.Second)
	}

	// We are now ready to build the result.
	result := partition.QuotientDFA()

	// Done.
	return result
}

// ReachableStates returns a set containing the indices of all reachable states
// in the DFA.
func (dfa DFA) ReachableStates() util.IntSet {
	// Prepare the reachable and new sets.
	reachable := util.NewIntSetWithValue(dfa.StartingState)
	new := util.NewIntSetWithValue(dfa.StartingState)

	for {
		next := util.IntSet{}

		// Add adjacent states.
		for q := range new {
			for _, adj := range dfa.Succ(q) {
				next.Add(adj)
			}
		}

		// Remove the ones we know to be reachable.
		next.SubtractSet(reachable)

		if next.Empty() {
			break
		} else {
			new = next
			reachable.AppendSet(next)
		}
	}

	// Done.
	return reachable
}

// UnreachableStates returns a set containing the indices of all unreachable
// states in the DFA.
func (dfa DFA) UnreachableStates() util.IntSet {
	all := util.NewIntSetWithValues(dfa.AllStates())

	// Done.
	return all.Difference(dfa.ReachableStates())
}

// HasUnreachableStates determines whether this DFA has unreachable states.
func (dfa DFA) HasUnreachableStates() bool {
	return len(dfa.ReachableStates()) != len(dfa.States)
}

// DeleteUnreachableStates deletes all unreachable states in the DFA.
func (dfa *DFA) DeleteUnreachableStates() {
	// Delete them.
	dfa.DeleteStates(dfa.UnreachableStates().Slice())
}

// DistinguishablePairs returns a set of all the distinguishable pairs of states
// in the DFA (as defined in Hopcrofts's minimisation algorithm).
func (dfa *DFA) DistinguishablePairs() util.IntPairSet {
	// Distinguishable pairs will be stored in a map: <Key=Cantor, Value=Pair>
	var distinguishablePairs = util.IntPairSet{}

	// Get all the pairs of states in the DFA.
	allPairs := dfa.PairsOfStates()

	// Find all trivially distinguisable pairs.
	for _, pair := range allPairs {
		if dfa.States[pair.First].Label != dfa.States[pair.Second].Label {
			distinguishablePairs.Add(pair)
		}
	}

	// Mark pairs if their successors are distinguishable.
	for {
		mark := false

		for symbol := range dfa.Alphabet {
			for _, pair := range allPairs {

				// Get next.
				next1 := dfa.States[pair.First].Next[symbol]
				next2 := dfa.States[pair.Second].Next[symbol]
				foundNext1 := next1 >= 0
				foundNext2 := next2 >= 0

				if foundNext1 && foundNext2 {
					// We are storing pairs in the set where First <= Second
					// so we need to sort.
					innerPair := util.IntPair{First: next1, Second: next2}
					innerPair.Sort()

					if distinguishablePairs.Contains(innerPair) && !distinguishablePairs.Contains(pair) {
						distinguishablePairs.Add(pair)
						mark = true
					}
				}
			}
		}

		if !mark {
			break
		}
	}

	// Done.
	return distinguishablePairs
}

// DistinguishablePairs returns a set of all the indistinguishable pairs of
// states in the DFA (as defined in Hopcrofts's minimisation algorithm).
func (dfa *DFA) IndistinguishablePairs() util.IntPairSet {
	// Get all pairs in DFA, and all the distinguishable ones.
	allPairs := dfa.PairsOfStates()
	distinguishablePairs := dfa.DistinguishablePairs()

	// Placeholder for result.
	indistinguishablePairs := util.NewIntPairSetWithCapacity(len(allPairs) - len(distinguishablePairs))

	// Loop thru each pair in the DFA and if it is not distinguishable
	// then it must be indistinguishable.
	for _, pair := range allPairs {
		if !distinguishablePairs.Contains(pair) {
			indistinguishablePairs.Add(pair)
		}
	}

	// Done.
	return indistinguishablePairs
}
