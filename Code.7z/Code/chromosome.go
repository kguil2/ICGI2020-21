// *****************************************************************************
// Kristian Guillaumier, 2019, 2021
// Types and functions to represent and manage chromosomes in the GA.
// *****************************************************************************

package genetic

import (
	"sort"

	"kguil.com/dfago"
	"kguil.com/dfago/util"
)

// ---- TYPES ------------------------------------------------------------------

// A chromosome in the GA.
type chromosome struct {
	merges  []util.IntPair // The merges in the chromosome.
	fitness int            // The fitness of the chromosome.
	dirty   bool           // Whether the fitness of the chromosome needs to be recomputed.
	gen     *genetic       // Keep a reference to the instance.
}

// ---- FUNCTIONS --------------------------------------------------------------

// Create a random chromosome. The fitness of the new chromosome is marked as
// dirty.
func (ga *genetic) randomChromosome() chromosome {
	// Create the  chromosome.
	result := chromosome{
		merges:  make([]util.IntPair, 0, ga.params.ChromosomeLength),
		fitness: 0,
		dirty:   true,
		gen:     ga}

	// Shuffle the order of merges in the pool.
	ga.shuffleMergePool()

	// Create the starting partition and a snapshot.
	partition := ga.apta.StatePartition()
	snapshot := partition.Snapshot()

	// Loop thru the shuffled merges.
	for _, merge := range ga.mergePool {
		// If the states to merge are in the same block, then they are identity
		// merges. Skip them.
		if snapshot.Find(merge.First) == snapshot.Find(merge.Second) {
			continue
		}

		// If the merge is valid (non-blocking), accept it.
		if snapshot.DetMerge(merge.First, merge.Second) {
			// Accept the merge and append it to the chromosome.
			result.merges = append(result.merges, merge)
			snapshot.CommitTo(&partition)

			// Get out if we reached the desired chromosome length.
			if len(result.merges) >= ga.params.ChromosomeLength {
				break
			}
		} else {
			snapshot.RollbackFrom(partition)
		}
	}

	// Done.
	return result
}

// Determines whether two chromosomes contain the same merges.
func (chrom chromosome) mergesEqualTo(other chromosome) bool {
	if chrom.length() == other.length() {
		chrom.sort()
		other.sort()
		for i := range chrom.merges {
			if chrom.merges[i] != other.merges[i] {
				return false
			}
		}
		return true
	}
	return false
}

// Returns the length (number of merges) in the chromosome.
func (chrom chromosome) length() int {
	return len(chrom.merges)
}

// Returns the number of colour-compatible merges in a chromosome. Will always
// return zero if the GA was instantiated with an empty APTA target map. Note
// that the GA uses colour-compatibility only for analysis.
func (chrom chromosome) numCC() (count int) {
	for _, merge := range chrom.merges {
		if chrom.gen.ccMergePool.Contains(merge) {
			count++
		}
	}
	return
}

// Sorts all the merges (pairs) in the chromosome.
func (chrom chromosome) sort() {
	sort.Slice(chrom.merges, func(i, j int) bool {
		if chrom.merges[i].First < chrom.merges[j].First {
			return true
		}

		if chrom.merges[i].First == chrom.merges[j].First {
			return chrom.merges[i].Second < chrom.merges[j].Second
		}

		return false
	})
}

// Executes all the merges in a chromosome starting from the APTA and returns
// the partition reached. Panics if there is an blocking merge (which should
// be impossible).
func (chrom chromosome) partition() dfago.StatePartition {
	// Start from the APTA.
	partition := chrom.gen.apta.StatePartition()

	// Execute all the merges.
	for _, merge := range chrom.merges {
		// A merge in a chromosome cannot be invalid. Panic if we find one.
		if !partition.DetMerge(merge.First, merge.Second) {
			panic("the chromosome contains an invalid/blocking merge")
		}
	}

	// Done.
	return partition
}

// Completely extends a chromosome using FW-EDSM to get the DFA it represents.
func (chrom chromosome) dfa() dfago.DFA {
	// EDSM scoring function.
	trainingSize := chrom.gen.apta.NumLabelled()

	edsm := func(b1, b2 int, before, after dfago.StatePartition, mergeStep int) (score float64, ok bool) {
		return float64(trainingSize - after.NumLabelledBlocks()), true
	}

	// Extend and return the DFA.
	chromPart := chrom.partition()
	finalPart, _ := chromPart.WindowedSearch(util.MaxInt, chrom.gen.params.TargetSize*2, 2.0, edsm)

	// Done.
	return finalPart.QuotientDFA()
}
