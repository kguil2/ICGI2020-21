// *****************************************************************************
// Kristian Guillaumier, 2017, 2020
// Measures the quality of a DFA with respect to a testing set.
// *****************************************************************************

package dfago

// ---- MEASURE QUALITY OF A HYPOTHESIS IN A TESTING SET -----------------------

// Accuracy returns the accuracy of a DFA in a testing set. Accuracy is given
// by (TP+TN)/(P+N).
func (dfa DFA) Accuracy(testingSet Dataset) float64 {
	// Make sure that the testing set is not empty.
	if testingSet.Size() == 0 {
		panic("The testing set is empty.")
	}

	// Count the true positives.
	tp := 0

	for _, sample := range testingSet.Positive {
		if dfa.Parse(sample) {
			tp++
		}
	}

	// Count the true negatives.
	tn := 0

	for _, sample := range testingSet.Negative {
		if !dfa.Parse(sample) {
			tn++
		}
	}

	// Done.
	return float64(tp+tn) / float64(testingSet.Size())
}

// Recall returns the recall (sensitivity/true positive rate) of a DFA in a
// testing set. Recall is given by TP/P.
func (dfa DFA) Recall(testingSet Dataset) float64 {
	// Make sure that the testing set is not empty.
	if testingSet.Size() == 0 {
		panic("The testing set is empty.")
	}

	// Count the correct matches in the positive samples.
	tp := 0

	for _, sample := range testingSet.Positive {
		if dfa.Parse(sample) {
			tp++
		}
	}

	// Done.
	return float64(tp) / float64(testingSet.NumPositive())
}

// Precision returns the precision (positive predictive value) of a DFA in a
// testing set. Precision is given by TP/(TP+FP).
func (dfa DFA) Precision(testingSet Dataset) float64 {
	// Make sure that the testing set is not empty.
	if testingSet.Size() == 0 {
		panic("The testing set is empty.")
	}

	// Count the true positives.
	tp := 0

	for _, sample := range testingSet.Positive {
		if dfa.Parse(sample) {
			tp++
		}
	}

	// Count the false positives.
	fp := 0

	for _, sample := range testingSet.Negative {
		if dfa.Parse(sample) {
			fp++
		}
	}

	// Done.
	return float64(tp) / float64(tp+fp)
}

// F1Score computes the F1 score of a DFA in a testing set. The F1 score is
// given by 2*(Precision*Recall)/(Precision + Recall).
func (dfa DFA) F1Score(testingSet Dataset) float64 {
	// Compute precision and recall.
	precision := dfa.Precision(testingSet)
	recall := dfa.Recall(testingSet)

	// Done.
	return 2.0 * (precision * recall) / (precision + recall)
}

// ---- SYNONYMS ON TESTING SETS -----------------------------------------------

// Accuracy returns the accuracy of a DFA in a testing set. Accuracy is given
// by (TP+TN)/(P+N).
func (set Dataset) Accuracy(dfa DFA) float64 {
	return dfa.Accuracy(set)
}

// Recall returns the recall (sensitivity/true positive rate) of a DFA in a
// testing set. Recall is given by TP/P.
func (set Dataset) Recall(dfa DFA) float64 {
	return dfa.Recall(set)
}

// Precision returns the precision (positive predictive value) of a DFA in a
// testing set. Precision is given by TP/(TP+FP).
func (set Dataset) Precision(dfa DFA) float64 {
	return dfa.Precision(set)
}

// F1Score computes the F1 score of a DFA in a testing set. The F1 score is
// given by 2*(Precision*Recall)/(Precision + Recall).
func (set Dataset) F1Score(dfa DFA) float64 {
	return dfa.F1Score(set)
}
