// *****************************************************************************
// Kristian Guillaumier, 2017, 2021
// Maps every state in an APTA to the corresponding state in the target DFA
// from where this APTA came from.
//
// NOTE: If the APTA (training set) is structurally complete or symmetrically
//       structurally complte with respect to the target and we merge all the
//       states in the APTA by their target mapping, then the resulting
//       quotient DFA would be exactly equal to the target DFA.
// *****************************************************************************

package dfago

import (
	"kguil.com/dfago/util"
)

// ---- TYPES ------------------------------------------------------------------

// AptaTargetMap maps every state in an APTA to the corresponding state in the
// target DFA from where this APTA came from. This is a slice where the index
// is the state index in the APTA and the value is the corresponding state
// index in target DFA.
type AptaTargetMap []int

// ---- MAP --------------------------------------------------------------------

// NewAptaTargetMap creates the APTA-to-Target map. This function will panic
// if the given DFA is not an APTA (it is not a tree).
func NewAptaTargetMap(apta DFA, targetDfa DFA) AptaTargetMap {
	// Prepare the empty mapping.
	result := make(AptaTargetMap, len(apta.States))

	// Store the symbols we have seen so far.
	stack := util.IntStack{}

	// Visited set (if a state is visited more than once, this is not a tree).
	visited := util.IntSet{}

	// The DFS function.
	var dfs func(currentState, currentSymbol int)

	dfs = func(currentState int, currentSymbol int) {
		if visited.Contains(currentState) {
			panic("the APTA is not a tree")
		}

		// Add the symbol to the stack and mark visited.
		if currentSymbol != -1 {
			stack.Push(int(currentSymbol))
		}
		visited.Add(currentState)

		// The current sub sample/string is in the stack. Add it to the mapping.
		{
			stateInTarget, ok := targetDfa.ParseToState(Sample(stack))

			if !ok {
				panic("a prefix in the APTA is not in the target (should be impossible)")
			}

			result[currentState] = stateInTarget
		}

		// Recursively visit children.
		for symbol, next := range apta.Succ(currentState) {
			dfs(next, symbol)
		}

		// Children done, step back.
		stack.Pop()
	}

	// Do a recursive DFS to enumerate all the samples/strings (including the
	// internal ones in the APTA). -1 is the dummy symbol going into the
	// starting state which will be ignored by the dfs() function.
	dfs(apta.StartingState, -1)

	// Done.
	return result
}

// NewEmptyAptaTargetMap creates an empty APTA-to-Target map.
func NewEmptyAptaTargetMap() AptaTargetMap {
	return AptaTargetMap{}
}

// Match determines whether the given states in an APTA map to the same state
// in the target DFA.
//
// NOTE: Do not use this to test whether the states in a partition block are
// colour-compatible. To check whether a partition or block is colour-compatible
// use the built-in colour-compatibility functions in the partition because they
// are significantly faster than this.
func (targetMap AptaTargetMap) Match(statesInAPTA []int) bool {
	// Base check.
	if len(statesInAPTA) == 0 {
		return true
	}

	// Get target state for first.
	targetState := targetMap[statesInAPTA[0]]

	// Check that all the remaining states have the same target state.
	for i := 1; i < len(statesInAPTA); i++ {
		if targetMap[statesInAPTA[i]] != targetState {
			return false
		}
	}

	// All ok.
	return true
}

// Pivot pivots the table. The original table has key=[state in APTA],
// value=[state in target]. This will convert to key=[state in target],
// value=[slice/list of states in APTA].
func (targetMap AptaTargetMap) Pivot() map[int][]int {
	result := make(map[int][]int)

	// Invert the table.
	for k, v := range targetMap {
		result[v] = append(result[v], k)
	}

	// Done.
	return result
}

// Size returns the size of the APTA target map. This is the same as the number
// of states in the APTA which created this map.
func (colourMap AptaTargetMap) Size() int {
	return len(colourMap)
}

// Empty determines whether this is an empty (uninitialised) APTA target map.
func (colourMap AptaTargetMap) Empty() bool {
	return len(colourMap) == 0
}

// NotEmpty determines whether this is an initialised APTA target map.
func (colourMap AptaTargetMap) NotEmpty() bool {
	return len(colourMap) != 0
}
