// *****************************************************************************
// Kristian Guillaumier, 2017, 2020
// Defines alphabet symbols and samples in DfaGo.
// *****************************************************************************

package dfago

// ---- TYPES ------------------------------------------------------------------

// Sample is a sequence or string of alphabet symbols.
type Sample []int

// ---- FUNCTIONS --------------------------------------------------------------

// Equal determines whether two slices are equal.
func (sample Sample) Equal(other Sample) bool {
	if len(sample) != len(other) {
		return false
	}

	for i := range sample {
		if sample[i] != other[i] {
			return false
		}
	}
	return true
}

// ---- UTILITIES --------------------------------------------------------------

// BinaryStringToSample converts a binary string consisting of either {0,1}s
// or {a,b}s to a sample.
func BinaryStringToSample(str string) (sample Sample) {
	// Prepare.
	sample = make(Sample, len(str))

	// Put them all.
	for i, ch := range str {
		if ch == '0' || ch == 'a' {
			sample[i] = 0
		} else if ch == '1' || ch == 'b' {
			sample[i] = 1
		} else {
			panic("Invalid character in binary string.")
		}
	}
	return sample
}
