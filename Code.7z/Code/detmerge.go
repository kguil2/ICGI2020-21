// *****************************************************************************
// Kristian Guillaumier, 2017, 2021
// This is the DetMerge operation in a state partition.
//
// OPTIMISATION NOTE: There is a slow version and a regular version. The slow
// version is the reference implementation which is optimised for readability.
// The regular version is functionally identical with all the internal calls
// inlined for performance. The improvement is significant.
// *****************************************************************************

package dfago

import "fmt"

// DetMergeSlow is a slow but clear reference implementation of DetMerge().
// This version should never be used in production.
func (part *StatePartition) DetMergeSlow(anyStateIndex1, anyStateIndex2 int) bool {
	// Warning.
	fmt.Printf("****************************************\n")
	fmt.Printf("YOU ARE USING DetMergeSlow()")
	fmt.Printf("****************************************\n")

	// Resolve the states to their blocks.
	anyStateIndex1 = part.Find(anyStateIndex1)
	anyStateIndex2 = part.Find(anyStateIndex2)

	// If the blocks we are merging are the same, there's nothing to do.
	if anyStateIndex1 == anyStateIndex2 {
		return true
	}

	// Use pointers to avoid slice indexing.
	label1, label2 := part.nodes[anyStateIndex1].label, part.nodes[anyStateIndex2].label

	// Check label compatibility.
	if (label1 == Accepting && label2 == Rejecting) || (label1 == Rejecting && label2 == Accepting) {
		return false
	}

	// Compute the union of the states.
	part.Union(anyStateIndex1, anyStateIndex2)

	// Resolve non-determinism.
	for symbol := 0; symbol < part.alphabetSize; symbol++ {
		next1 := part.nodes[anyStateIndex1].next[symbol]
		next2 := part.nodes[anyStateIndex2].next[symbol]

		if next1 == -1 || next2 == -1 {
			continue
		}

		if !part.DetMergeSlow(next1, next2) {
			return false
		}
	}

	// All OK.
	return true
}

// DetMerge deterministically merges the block containing a state with the block
// containing another state. Returns true if the detmerge was successful or
// false if the resulting partition is invalid (one or more blocks contain mixed
// accepting and rejecting states). If the detmerge is invalid, the partition is
// 'corrupted' and should be discarded or rolled back.
func (part *StatePartition) DetMerge(anyStateIndex1, anyStateIndex2 int) bool {
	// Resolve the states to their blocks.
	if part.nodes[anyStateIndex1].parent != anyStateIndex1 {
		anyStateIndex1 = part.Find(anyStateIndex1)
	}

	if part.nodes[anyStateIndex2].parent != anyStateIndex2 {
		anyStateIndex2 = part.Find(anyStateIndex2)
	}

	// If the blocks we are merging are the same, there's nothing to do.
	if anyStateIndex1 == anyStateIndex2 {
		return true
	}

	// Use pointers to avoid slice indexing.
	ptr1, ptr2 := &part.nodes[anyStateIndex1], &part.nodes[anyStateIndex2]

	// Check label compatibility.
	if (ptr1.label == Accepting && ptr2.label == Rejecting) || (ptr1.label == Rejecting && ptr2.label == Accepting) {
		return false
	}

	// Compute the union of the states.
	// ----> INLINE::UNION() ---->
	{
		// Merge smaller block into the larger one (union by rank/size).
		if ptr1.size < ptr2.size {
			ptr1, ptr2 = ptr2, ptr1
			anyStateIndex1, anyStateIndex2 = anyStateIndex2, anyStateIndex1
		}

		// Log all changes if in snapshot mode.
		if part.snapshot {
			// ----> INLINE::MARKDIRTY() ---->
			if !ptr1.dirty {
				part.changedNodes[part.changedCount] = anyStateIndex1
				part.changedCount++
				ptr1.dirty = true
			}
			// <---- INLINE::MARKDIRTY() <----

			// ----> INLINE::MARKDIRTY() ---->
			if !ptr2.dirty {
				part.changedNodes[part.changedCount] = anyStateIndex2
				part.changedCount++
				ptr2.dirty = true
			}
			// <---- INLINE::MARKDIRTY() <----
		}

		// A block will be 'deleted' by the union.
		part.numBlocks--

		// Correct the number of labelled blocks in the partition.
		if ptr1.label == Accepting && ptr2.label == Accepting {
			part.numAccepting--
		} else if ptr1.label == Rejecting && ptr2.label == Rejecting {
			part.numRejecting--
		}

		// Resolve the label of the parent after the union.
		if ptr1.label == Unlabelled {
			ptr1.label = ptr2.label
		}

		// The size of the block will increase.
		ptr1.size += ptr2.size

		// Correct the transitions.
		for symbol := 0; symbol < part.alphabetSize; symbol++ {
			// If the parent has no transition for the symbol, inherit it from the child.
			if ptr1.next[symbol] == -1 {
				ptr1.next[symbol] = ptr2.next[symbol]
			}
		}

		// Make the child point to the parent.
		ptr2.parent = anyStateIndex1
		ptr1.back, ptr2.back = ptr2.back, ptr1.back
	}
	// <---- INLINE::UNION() <----

	// Resolve non-determinism.
	for symbol := 0; symbol < part.alphabetSize; symbol++ {
		next1 := ptr1.next[symbol]
		next2 := ptr2.next[symbol]

		if next1 == -1 || next2 == -1 {
			continue
		}

		if !part.DetMerge(next1, next2) {
			return false
		}
	}

	// All OK.
	return true
}
