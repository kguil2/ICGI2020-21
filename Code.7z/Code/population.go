// *****************************************************************************
// Kristian Guillaumier, 2019, 2021
// Types and functions to manage populations in the GA.
// *****************************************************************************

package genetic

import "sort"

// ---- TYPES ------------------------------------------------------------------

// A population is a slice of chromosomes.
type population []chromosome

// ---- FUNCTIONS --------------------------------------------------------------

// Determines whether a population contains a chromosome.
func (p population) contains(chrom chromosome) bool {
	for _, c := range p {
		if chrom.mergesEqualTo(c) {
			return true
		}
	}
	return false
}

// Returns a value in the range (0,1] where a value of 1 indicates that all the
// chromosomes in the population are different. Lower values indicate that there
// are many duplicate chromosomes.
//
// NOTE: although this is only used in verbose mode, this is pretty inefficient
//       and could be improved.
func (p population) diversity() float64 {
	// Prepare the new population.
	newPopulation := make(population, 0, len(p))

	// Filter out.
	for _, chrom := range p {
		if !newPopulation.contains(chrom) {
			newPopulation = append(newPopulation, chrom)
		}
	}

	// Done.
	return float64(len(newPopulation)) / float64(len(p))
}

// Sorts the population by fitness ascending (fittest/smallest on top). Of
// course, this assumes that the fitness of the population is computed.
func (p population) sort() {
	sort.Slice(p, func(i, j int) bool {
		return p[i].fitness < p[j].fitness
	})
}

// Attempts to append a chromosome to a population if it is not already in it.
// If the chromosome is already in the population, the retry function will be
// called up to a maximum number times to request a different one.
func (p *population) appendDistinct(chrom chromosome, maxAttempts int, retry func() chromosome) {
	attempts := 0

	for attempts < maxAttempts && p.contains(chrom) {
		// Request a new one.
		chrom = retry()
	}

	// Append.
	(*p) = append((*p), chrom)
}
