// *****************************************************************************
// Kristian Guillaumier, 2017, 2020
// Contains functions to construct PTAs or APTAs from training sets.
// *****************************************************************************

package dfago

// ---- PTAs and APTAs  --------------------------------------------------------

// PTA creates a PTA from a training set (dataset).
func (set Dataset) PTA(alphabetSize int) DFA {
	// Create the APTA.
	dfa := NewSizedDFA(alphabetSize, set.Size())

	// Insert the positive samples in the training set.
	for _, sample := range set.Positive {
		dfa.InsertSample(sample, Accepting)
	}

	// Done.
	return dfa
}

// APTA creates an APTA from a training set (dataset).
func (set Dataset) APTA(alphabetSize int) DFA {
	// Create the APTA.
	dfa := NewSizedDFA(alphabetSize, set.Size())

	// Insert the positive samples in the training set.
	for _, sample := range set.Positive {
		dfa.InsertSample(sample, Accepting)
	}

	// Insert the negative samples in the training set.
	for _, sample := range set.Negative {
		dfa.InsertSample(sample, Rejecting)
	}

	// Done.
	return dfa
}

// InsertSample is primarily used for building PTAs and APTAs by inserting the
// samples in a training set into an empty DFA. This sample is 'injected' into
// the DFA by building a path of states and transitions corresponding to each
// symbol in the sample and labelling the state reached by the sample. Panics
// if the sample is inconsistent with the DFA (e.g. an accepting sample reaches
// a rejecting state in the DFA).
func (dfa *DFA) InsertSample(sample Sample, label StateLabel) {
	// If the DFA is empty, create the starting state.
	if len(dfa.States) == 0 {
		// Create the starting state.
		dfa.StartingState = dfa.AddState(Unlabelled)
	}

	// Check the starting state.
	if dfa.StartingState < 0 || dfa.StartingState >= len(dfa.States) {
		panic("The starting state is invalid.")
	}

	// Start from the starting state.
	currentState := dfa.StartingState

	// Loop thru each symbol in the sample.
	for _, symbol := range sample {
		// Make sure that the symbol is in the DFA's alphabet.
		if symbol < 0 || symbol >= dfa.AlphabetSize() {
			panic("A symbol in the sample is not in the DFA's alphabet.")
		}

		// Visit or create a new state.
		if next := dfa.States[currentState].Next[symbol]; next >= 0 {
			// If a next state exists for this symbol, visit it.
			currentState = next
		} else {
			// Otherwise, create it.
			newState := dfa.AddState(Unlabelled)

			// Create the transition.
			dfa.AddTransition(currentState, newState, symbol)

			// Visit.
			currentState = newState
		}
	}

	// Label the last state as requested.
	if dfa.States[currentState].Unlabelled() {
		dfa.States[currentState].Label = label
	} else if dfa.States[currentState].Label != label {
		panic("The sample with the requested label cannot be inserted because it reaches a state having a different label.")
	}
}

// InsertBinaryString is primarily used for building PTAs and APTAs by inserting
// the samples in a training set into an empty DFA. This sample is 'injected'
// into the DFA by building a path of states and transitions corresponding to
// each symbol in the sample and labelling the state reached by the sample. The
// string is defined over the alphabet {a,b} or {0,1}. Panics if the sample
// is inconsistent with the DFA (e.g. an accepting sample reaches a rejecting
// state in the DFA).
func (dfa *DFA) InsertBinaryString(str string, label StateLabel) {
	dfa.InsertSample(BinaryStringToSample(str), label)
}
