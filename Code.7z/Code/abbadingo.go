// *****************************************************************************
// Kristian Guillaumier, 2017, 2020
// Creates Abbadingo-style DFAs, training sets and testing sets.
// *****************************************************************************

package dfago

import (
	"math"
	"math/rand"
	"strconv"

	"kguil.com/dfago/util"
)

// ---- CREATE AN ABBADINGO INSTANCE -------------------------------------------

// NewAbbadingoInstance creates a new Abbadingo instance consisting of a
// target DFA, a training set, and a testing set.
func NewAbbadingoInstance(nominalSize int, exact bool, trainingSetSize, testingSetSize int) (target DFA, trainingSet, testingSet Dataset) {
	target = NewAbbadingoDFA(nominalSize, exact)
	trainingSet, testingSet = NewAbbadingoDatasets(target, nominalSize, trainingSetSize, testingSetSize)
	return
}

// ---- CREATE ABBADINGO DFAS --------------------------------------------------

// NewAbbadingoDFA returns an Abbadingo-style random DFA having approximately
// the number of states requested. If exact is true, the DFA returned will have
// exactly that number of states requested.
func NewAbbadingoDFA(nominalSize int, exact bool) DFA {
	// Initial graph size contains (5/4)n nodes.
	graphSize := util.Round(5.0 * float64(nominalSize) / 4.0)

	// How deep should the DFA be.
	requiredDepth := util.Round((2.0 * math.Log2(float64(nominalSize))) - 2.0)

	// Repeat until we get the DFA we want.
	for {
		// Create the DFA - Abbadingo DFAs have 2 symbols.
		dfa := NewSizedDFA(2, graphSize)

		// Create the states.
		for i := 0; i < graphSize; i++ {
			// Random 50/50 that the state will be accepting/unlabelled.
			if (rand.Int() % 2) == 0 {
				dfa.AddState(Accepting)
			} else {
				dfa.AddState(Unlabelled)
			}
		}

		// Create the transitions for each state.
		for fromState := 0; fromState < graphSize; fromState++ {
			// Get a random target state for the symbol 'a'.
			dfa.AddTransition(fromState, (rand.Int() % graphSize), 0)

			// Get a random target state for the symbol 'b'.
			dfa.AddTransition(fromState, (rand.Int() % graphSize), 1)
		}

		// Select a random starting state.
		dfa.StartingState = rand.Int() % graphSize

		// Minimise the DFA.
		dfa = dfa.Minimise()

		// Break if this is the DFA we want.
		if dfa.Depth() == requiredDepth {
			// Do we want the DFA to have the exact number of states?
			if exact {
				if len(dfa.States) == nominalSize {
					return dfa
				}
			} else {
				return dfa
			}
		}
	}
}

// ---- CREATE TRAINING AND TESTING SETS ---------------------------------------

/*
THIS IS THE STRATEGY WE WILL USE:

* There exists a mapping (bijection) between every natural number n>0 and a
  binary string.

* This is shown in the table below. Note how the binary representation of a
  decimal number is exactly the string we are mapping to with the most
  significant bit removed. For example, decimal 9 is 1001 in binary. After
  removing the most significant bit 1, we get 001 (i.e. the string aab).

	+------------+--------------+-------------+
	| bit string | n in decimal | n in binary |
	+------------+--------------+-------------+
	|          ε |            1 |           1 |
	|          0 |            2 |          10 |
	|          1 |            3 |          11 |
	|         00 |            4 |         100 |
	|         01 |            5 |         101 |
	|         10 |            6 |         110 |
	|         11 |            7 |         111 |
	|        000 |            8 |        1000 |
	|        001 |            9 |        1001 | <-- For example
	|        010 |           10 |        1010 |
	|        011 |           11 |        1011 |
	|        100 |           12 |        1100 |
	|        101 |           13 |        1101 |
	|        110 |           14 |        1110 |
	|        111 |           15 |        1111 | <- Max 3 chars. So 15=2^(3+1)-1
	|        ... |          ... |         ... |
	+------------+--------------+-------------+

* If we wish that the longest string have the length L, then the maximum decimal
  number in our scheme will be given by 2^(L+1)-1

* In other words, we can generate random numbers between [1, 2^(L+1)-1] to
  generate random strings having a length between 0 and L.

*/

// NewAbbadingoDatasets returns an Abbadingo-style training and testing set.
// This function needs to know the nominal size of the target DFA (e.g. 32, 64,
// 128, ...) to determine the length of the longest string in the datasets
// it creates. Since these datasets are Abbadingo-style, the alphabet will
// be binary {0,1}.
//
// * target:			The target DFA to create the training set and
//						testing set for.
// * nominalSize:		The nominal size of the target DFA.
// * trainingSetSize:	The desired size of the training set we want.
// * testingSetSize: 	The desired size of the testing set we want.
func NewAbbadingoDatasets(target DFA, nominalSize int, trainingSetSize, testingSetSize int) (trainingSet Dataset, testingSet Dataset) {
	// Compute the length of the longest string in the training set (according
	// to Abbadingo rules)
	maxLength := util.Round(2.0*math.Log2(float64(nominalSize)) + 3.0)

	// In our (number -> string) mapping, this will be maximum number for our
	// maximum string length (see explanation above).
	maxDecimal := util.PowInt(2, maxLength+1) - 1

	// Fill a set with random numbers in the range [1, maxLength].
	randomNumbers := util.NewIntSetWithCapacity(trainingSetSize + testingSetSize)

	// The total number of strings we want.
	requestedStrings := trainingSetSize + testingSetSize

	// Due to the way we are selecting random numbers without repetition, we
	// have to ensure that the 'pool' of number we are extracting from is
	// large enough. Here we are requiring that the total number of strings
	// requested is not more than 20% (chosen by trial-and-error) than the
	// size of the pool.
	if float64(requestedStrings)/float64(maxDecimal) > 0.5 {
		panic("there is a risk that the pool of strings too choose from is not enough to fill sets of the required size")
	}

	// Fill until we have enough for the both sets we need.
	for len(randomNumbers) < requestedStrings {
		// Create the random number/string.
		rnd := rand.Intn(maxDecimal) + 1 // +1 because we want to start with 1.

		// Add it to the set.
		randomNumbers.Add(rnd)
	}

	// Prepare the sets where we'll temporarily store the strings.
	trainingAccepting := util.StringSet{}
	trainingRejecting := util.StringSet{}
	testingAccepting := util.StringSet{}
	testingRejecting := util.StringSet{}

	// Now convert the numbers to a binary string and put them in the right set.
	for num := range randomNumbers {
		// Convert this number to a binary string. This will always start
		// with a '1'.
		str := strconv.FormatInt(int64(num), 2)

		// Remove leading '1'.
		str = str[1:]

		// Parse the sample and decide whether it is accepted or rejected by
		// the classifier.
		if trainingAccepting.Count()+trainingRejecting.Count() < trainingSetSize {
			// Add to the training set.
			if target.ParseBinaryString(str) {
				trainingAccepting.Add(str)
			} else {
				trainingRejecting.Add(str)
			}
		} else {
			// Add to the testing set.
			if target.ParseBinaryString(str) {
				testingAccepting.Add(str)
			} else {
				testingRejecting.Add(str)
			}
		}
	}

	// Create the actual datasets, and put everything in the right place.
	trainingSet = NewDatasetWithCapacity(len(trainingAccepting), len(trainingRejecting))
	testingSet = NewDatasetWithCapacity(len(testingAccepting), len(testingRejecting))

	for s := range trainingAccepting {
		trainingSet.AddPositive(BinaryStringToSample(s))
	}

	for s := range trainingRejecting {
		trainingSet.AddNegative(BinaryStringToSample(s))
	}

	for s := range testingAccepting {
		testingSet.AddPositive(BinaryStringToSample(s))
	}

	for s := range testingRejecting {
		testingSet.AddNegative(BinaryStringToSample(s))
	}

	return
}
