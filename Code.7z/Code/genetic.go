// *****************************************************************************
// Kristian Guillaumier, 2019, 2021
// A genetic algorithm used to evolve good short merge sequences. The
// idea is to maximise the number of colour-compatible merges in a chromosome
// so that when they're extended with FW-EDSM there is a high likelihood of
// finding a good hypothesis.
// *****************************************************************************

package genetic

import (
	"fmt"
	"math/rand"
	"runtime"
	"time"

	"kguil.com/dfago"
	"kguil.com/dfago/util"
)

// ---- TYPES ------------------------------------------------------------------

// The instance of the algorithm.
type genetic struct {
	apta        dfago.DFA       // The starting APTA.
	params      Parameters      // The GA parameters.
	population  population      // The population of chromosomes.
	mergePool   []util.IntPair  // The is the pool of merges to fill chromosomes with.
	ccMergePool util.IntPairSet // This is a subset of the merges in the merge pool which are colour-compatible (only used for analysis).
}

// Parameters are the parameters to run the genetic algorithm.
type Parameters struct {
	TargetSize             int     // The algorithm needs to know the size of the target we are looking for.
	PopulationSize         int     // The size of the population.
	MaxGenerations         int     // The maximum number of fast (estimated) generations to run.
	Plateau                int     // If the best fitness remains the same for this number of fast generations, we detect a plateau and stop.
	TerminateOnZero        bool    // The whether the generations will stop whenever a chromosome with a fitness of zero is found.
	TournamentSize         int     // Size for tournament selection.
	ChromosomeLength       int     // The length of chromosomes to evolve.
	MergeTableMinReduction int     // Parameter for creating the APTA merge table.
	MergeTableMinEdsm      int     // Parameter for creating the APTA merge table.
	MaxAttempts            int     // Retry attempts (e.g. ensuring that parents are different in crossover).
	CrossoverRate          float64 // Crossover rate <= 1.0 (crossover+elite <= 1.0).
	MutationRate           float64 // Mutation rate <= 1.0.
	EliteRate              float64 // Crossover rate <= 1.0 (crossover+elite <= 1.0).
	EstimatorK             int     // Estimator parameters for fast generations (we are estimating size, problem-specific).
	EstimatorM             float64 // Estimator parameters for fast generations (we are estimating size, problem-specific).
	EstimatorC             float64 // Estimator parameters for fast generations (we are estimating size, problem-specific).
	Concurrency            int     // The number of worker goroutines to use to evaluate the fitness of populations.
	ResultSearchWindow     int     // The DFA returned by the algorithm will be the best out of this number of fittest chromosomes.
	UseFastEstimator       bool    // Whether to use fast estimation to compute fitness.
	Verbose                bool    // Whether to run in verbose mode.
}

// Info is returned when the algorithm completes to describe the run.
type Info struct {
	TargetSize             int     // The algorithm needs to know the size of the target we are looking for.
	PopulationSize         int     // The size of the population.
	MaxGenerations         int     // The maximum number of generations to run.
	Plateau                int     // If the best fitness remains the same for this number of generations, we detect a plateau and stop.
	TerminateOnZero        bool    // The whether the generations will stop whenever a chromosome with a fitness of zero is found.
	TournamentSize         int     // Size for tournament selection.
	ChromosomeLength       int     // The length of chromosomes to evolve.
	MergeTableMinReduction int     // Parameter for creating the APTA merge table.
	MergeTableMinEdsm      int     // Parameter for creating the APTA merge table.
	MergePoolSize          int     // The number of merges in the merge pool.
	MergePoolSizeCC        int     // The number of colour-compat merges in the merge pool. Will be zero if the GA was given an empty APTA target map.
	MaxAttempts            int     // Retry attempts (e.g. ensuring that parents are different in crossover).
	CrossoverRate          float64 // Crossover rate <= 1.0 (crossover+elite <= 1.0).
	MutationRate           float64 // Mutation rate <= 1.0.
	EliteRate              float64 // Crossover rate <= 1.0 (crossover+elite <= 1.0).
	EstimatorK             int     // Estimator parameters for fast generations (we are estimating size, problem-specific).
	EstimatorM             float64 // Estimator parameters for fast generations (we are estimating size, problem-specific).
	EstimatorC             float64 // Estimator parameters for fast generations (we are estimating size, problem-specific).
	Concurrency            int     // The number of worker goroutines to use to evaluate the fitness of populations.
	TrackBest              []int   // The fitness of the fittest chromosomes in each fast generation.
	TerminationReason      int     // The reason the fast generation terminated.
	TotalEvaluations       int     // The total evaluations performed by fast generations.
	ActualGenerations      int     // The actual number of generations run.
	ResultSearchWindow     int     // The DFA returned by the algorithm will be the best out of this number of fittest chromosomes.
	UseFastEstimator       bool    // Whether to use fast estimation to compute fitness.
	Time                   float64 // The time taken by the run.
}

// This is the reason why a generation has terminated.
const (
	// Generation terminated due to an unspecified reason.
	TerminationReasonUnspecified = 0

	// Generation terminated because the maximum number of generations elapsed.
	TerminationReasonMaxElapsed = 1

	// Generation terminated because the fitness plateaued for too long.
	TerminationReasonPlateau = 2

	// Generation terminated because a chromosome with a fitness of 0 was found.
	TerminationReasonZero = 3
)

// ---- ALGORITHM --------------------------------------------------------------

// Run runs the GA and returns the best DFA found and a Info object
// describing the run. If a non-empty APTA colour map is provided, the GA will
// track and display colour-compatibility for analysis only. Colour-
// compatibility does not guide the search in any way.
func Run(apta dfago.DFA, aptaColours dfago.AptaTargetMap, params Parameters) (finalDFA dfago.DFA, info Info) {
	// Check that the params make sense.
	params.checkAndPanic()

	// Start time.
	start := time.Now()

	// Set the default concurrency if not specified.
	if params.Concurrency <= 0 {
		params.Concurrency = runtime.NumCPU() * 8
	}

	// -------------------------------------------------------------------------
	// STEP 1: Create an instance of the algorithm.
	// -------------------------------------------------------------------------
	ga := genetic{apta: apta, params: params}

	ga.printf("********************************************\n")
	ga.printf("GENETIC ALGORITHM\n")
	ga.printf("********************************************\n")
	ga.printf("Target DFA Size:        %d\n", params.TargetSize)
	ga.printf("APTA Size:              %d\n", len(apta.States))
	ga.printf("Population Size:        %d\n", params.PopulationSize)
	ga.printf("Max Generations:        %d\n", params.MaxGenerations)
	ga.printf("Fast Plateau:           %d\n", params.Plateau)
	ga.printf("Terminate on Zero:      %t\n", params.TerminateOnZero)
	ga.printf("Tournament Size:        %d\n", params.TournamentSize)
	ga.printf("Chromosome Length:      %d\n", params.ChromosomeLength)
	ga.printf("Min Reductions:         %d\n", params.MergeTableMinReduction)
	ga.printf("Min EDSM:               %d\n", params.MergeTableMinEdsm)
	ga.printf("Max Attempts:           %d\n", params.MaxAttempts)
	ga.printf("Crossover Rate:         %.2f%%\n", params.CrossoverRate*100.0)
	ga.printf("Mutation Rate:          %.2f%%\n", params.MutationRate*100.0)
	ga.printf("Elite Rate:             %.2f%%\n", params.EliteRate*100.0)
	ga.printf("Estimator K:            %d\n", params.EstimatorK)
	ga.printf("Estimator M:            %f\n", params.EstimatorM)
	ga.printf("Estimator C:            %f\n", params.EstimatorC)
	ga.printf("Result Search Window:   %d\n", params.ResultSearchWindow)
	ga.printf("Fast Estimator Mode:    %t\n", params.UseFastEstimator)
	ga.printf("Concurrency:            %d\n", params.Concurrency)
	ga.printf("Start:                  %s\n", time.Now().String())
	ga.printf("********************************************\n\n")

	// -------------------------------------------------------------------------
	// STEP 2: Create an APTA reduction table to get the merge pool.
	// -------------------------------------------------------------------------
	{
		// Build the table and get the merge pool. Pass any colour-compatibility
		// info if we have it (aptaColours may be empty). Colour-compatibility
		// is only used to display information and does not guide the search
		// in any way.
		table := dfago.NewAptaMergeTableCC(apta, params.MergeTableMinReduction, params.MergeTableMinEdsm, aptaColours)

		ga.printf("APTA Merge Table {\n")
		ga.printf("  Min. Reduction:         %d\n", table.MinimumReduction)
		ga.printf("  Min. EDSM:              %d\n", table.MinimumEDSM)
		ga.printf("  Total Merges Evaluated: %d\n", table.TotalMerges)
		ga.printf("  Merges:                 %d\n", len(table.Merges))
		ga.printf("  Colour-Compat. Merges:  %d\n", len(table.MergesCC))
		ga.printf("  Time:                   %.2fs\n", table.Time)
		ga.printf("}\n\n")

		// These are the merges we will use to build chromosomes.
		ga.mergePool = table.Merges

		// Colour-compatible merges are used for analysis only and does not
		// guide the search in any way.
		ga.ccMergePool = table.MergesCC

		// Sanity check.
		if len(ga.mergePool) == 0 {
			panic("the APTA reduction table is empty (the minimum reductions and/or minimum EDSM score is too high)")
		}
	}

	// -------------------------------------------------------------------------
	// STEP 3: Create the initial population.
	// -------------------------------------------------------------------------
	{
		ga.printf("Creating initial population... ")

		// Create.
		ga.population = make([]chromosome, params.PopulationSize)

		for i := 0; i < params.PopulationSize; i++ {
			ga.population[i] = ga.randomChromosome()
		}

		if params.Verbose {
			fmt.Printf("Done (diversity=%.2f).\n\n", ga.population.diversity())
		}
	}

	// -------------------------------------------------------------------------
	// STEP 4: Run the generations.
	// -------------------------------------------------------------------------
	trackBest, terminationReason, totalEvaluations := ga.runGenerations()

	// -------------------------------------------------------------------------
	// STEP 5: Prepare and decide which will be the DFA we return.
	// -------------------------------------------------------------------------
	{
		// Sort the population by fitness.
		ga.population.sort()

		// Assume that the best DFA is the first.
		finalDFA = ga.population[0].dfa()

		// Search in the remainder of the search window.
		for i := 1; i < params.ResultSearchWindow; i++ {
			dfa := ga.population[i].dfa()

			if dfa.NumStates() < finalDFA.NumStates() {
				finalDFA = dfa
			}
		}
	}

	// -------------------------------------------------------------------------
	// STEP 6: Prepare the info object describing this run.
	// -------------------------------------------------------------------------
	info = Info{
		TargetSize:             params.TargetSize,
		PopulationSize:         params.PopulationSize,
		MaxGenerations:         params.MaxGenerations,
		Plateau:                params.Plateau,
		TerminateOnZero:        params.TerminateOnZero,
		TournamentSize:         params.TournamentSize,
		ChromosomeLength:       params.ChromosomeLength,
		MergeTableMinReduction: params.MergeTableMinReduction,
		MergeTableMinEdsm:      params.MergeTableMinEdsm,
		MergePoolSize:          len(ga.mergePool),
		MergePoolSizeCC:        len(ga.ccMergePool),
		MaxAttempts:            params.MaxAttempts,
		CrossoverRate:          params.CrossoverRate,
		MutationRate:           params.MutationRate,
		EliteRate:              params.EliteRate,
		EstimatorK:             params.EstimatorK,
		EstimatorM:             params.EstimatorM,
		EstimatorC:             params.EstimatorC,
		Concurrency:            params.Concurrency,
		TrackBest:              trackBest,
		TerminationReason:      terminationReason,
		TotalEvaluations:       totalEvaluations,
		ActualGenerations:      len(trackBest),
		ResultSearchWindow:     params.ResultSearchWindow,
		UseFastEstimator:       params.UseFastEstimator,
		Time:                   time.Since(start).Seconds()}

	// -------------------------------------------------------------------------
	// STEP 7: Print some stuff before getting out.
	// -------------------------------------------------------------------------
	ga.printf("READY. DFA size: %d, Total evaluations: %d, Time: %.2fm/%.2fh\n",
		finalDFA.NumStates(),
		totalEvaluations,
		time.Since(start).Minutes(), time.Since(start).Hours())

	// Done.
	return finalDFA, info
}

// ---- GENETIC ALGORITHM ------------------------------------------------------

// Evaluate the fitness of an individual chromosome in the population.
func (ga genetic) evaluateFitnessOfChromosome(index, trainingSetSize int) {
	// Compute only if necessary.
	if !ga.population[index].dirty {
		return
	}

	// EDSM scoring function.
	edsm := func(b1, b2 int, before, after dfago.StatePartition, mergeStep int) (score float64, ok bool) {
		return float64(trainingSetSize - after.NumLabelledBlocks()), true
	}

	// Perform all the merges in the chromosome.
	partition := ga.population[index].partition()

	// Use fast or real fitness evaluation.
	if ga.params.UseFastEstimator {
		// Continue the chromosome but only up to the estimator length.
		result, _ := partition.WindowedSearch(ga.params.EstimatorK-ga.population[index].length(), ga.params.TargetSize*2, 2.0, edsm)

		// Estimate the size of the final DFA.
		edsmK := float64(trainingSetSize - result.NumLabelledBlocks())
		estimateSize := util.Round(edsmK*ga.params.EstimatorM + ga.params.EstimatorC)

		// Done - the fitness is the difference in size between the
		// hypothesis found and the target DFA.
		ga.population[index].fitness = util.AbsInt(ga.params.TargetSize - estimateSize)
	} else {
		// Continue the chromosome completely with W-EDSM.
		result, _ := partition.WindowedSearch(util.MaxInt, ga.params.TargetSize*2, 2.0, edsm)

		// Done - the fitness is the difference in size between the
		// hypothesis found and the target DFA.
		ga.population[index].fitness = util.AbsInt(ga.params.TargetSize - result.NumBlocks())
	}

	// OK.
	ga.population[index].dirty = false
}

// Evaluates the fitness of the population. Returns the index of the fittest
// chromosome in the population, the number of fitness evaluations performed,
// and the time taken to run.
func (ga genetic) evaluateFitness() (bestIndex, evaluations int, timeTaken float64) {
	// Start time.
	start := time.Now()

	// The number of evaluations this function will make is equal to the number
	// of dirty chromosomes.
	for i := range ga.population {
		if ga.population[i].dirty {
			evaluations++
		}
	}

	// We need the training set size to pass on to the evaluate function.
	trainingSetSize := ga.apta.NumLabelled()

	// -------------------------------------------------------------------------
	// The channel where we will receive the indices of the chromosomes we
	// have evaluated.
	producer := make(chan int, len(ga.population))
	consumer := make(chan int, len(ga.population))

	// -------------------------------------------------------------------------
	// Spawn the workers.
	for i := 0; i < ga.params.Concurrency; i++ {
		go func() {
			for index := range producer {
				// Do it.
				ga.evaluateFitnessOfChromosome(index, trainingSetSize)

				// Done signal.
				consumer <- index
			}
		}()
	}

	// -------------------------------------------------------------------------
	// Create the jobs.
	for i := 0; i < len(ga.population); i++ {
		producer <- i
	}

	// -------------------------------------------------------------------------
	// Consume the results. Track the best chromosome.
	bestIndex = -1
	bestFitness := util.MaxInt

	for i := 0; i < len(ga.population); i++ {
		// Get the index of the chromosome we processed.
		index := <-consumer

		// Remember the best.
		if ga.population[index].fitness < bestFitness {
			bestFitness = ga.population[index].fitness
			bestIndex = index
		}
	}

	// Close the channels.
	close(producer)
	close(consumer)

	// Done.
	return bestIndex, evaluations, time.Since(start).Seconds()
}

// Creates a new population from the current one using crossover, mutation, and
// elitism. Assumes that the fitness of the current population is already
// computed or estimated.
func (ga *genetic) evolveNewPopulation() population {
	// Create the new population.
	newPopulation := make(population, 0, ga.params.PopulationSize)

	// Establish the make up of the new population.
	byElitism := util.Min(util.Round(float64(ga.params.PopulationSize)*ga.params.EliteRate), ga.params.PopulationSize)
	byCrossover := util.Min(util.Round(float64(ga.params.PopulationSize)*ga.params.CrossoverRate), ga.params.PopulationSize)

	// Elitism.
	{
		// Sort the old population by fitness and copy the fittest over.
		ga.population.sort()
		newPopulation = append(newPopulation, ga.population[:byElitism]...)
	}

	// Crossover.
	{
		// Append a child to the new population.
		for len(newPopulation) < (byElitism + byCrossover) {
			// Try to make sure that what we're appending is not already in
			// the new population.
			newPopulation.appendDistinct(ga.offspring(), ga.params.MaxAttempts, func() chromosome {
				// Retry with another.
				return ga.offspring()
			})
		}
	}

	// Fill in the rest of the population with random chromosomes.
	for len(newPopulation) < ga.params.PopulationSize {
		// Try to make sure that what we're appending is not already in
		// the new population.
		newPopulation.appendDistinct(ga.randomChromosome(), ga.params.MaxAttempts, func() chromosome {
			// Retry with another.
			return ga.randomChromosome()
		})
	}

	// We're done.
	return newPopulation
}

// Run generations.
func (ga *genetic) runGenerations() (bestTracker []int, terminationReason, totalEvaluations int) {
	// Track the fitness of the best individual over each generation.
	bestTracker = []int{}

	// Why did the algorithm terminate. Max? Plateau? Threshold?
	terminationReason = TerminationReasonUnspecified

	// Remember the total evaluations performed.
	totalEvaluations = 0

	// Perform the required number of generations.
	for generation := 0; generation < ga.params.MaxGenerations; generation++ {
		// Estimate or compute the fitness of the population.
		bestIndex, evaluatons, time := ga.evaluateFitness()

		// Remember the total evaluations performed.
		totalEvaluations += evaluatons

		// Track the best as generations move on.
		bestTracker = append(bestTracker, ga.population[bestIndex].fitness)

		// Print info about the population.
		if ga.params.Verbose {
			mmaChromLen := util.NewMinMaxAvg()
			mmaChromCC := util.NewMinMaxAvg()
			mmaFitness := util.NewMinMaxAvg()

			for _, chromosome := range ga.population {
				mmaChromLen.AddInt(chromosome.length())
				mmaChromCC.AddInt(chromosome.numCC())
				mmaFitness.AddInt(chromosome.fitness)
			}

			// Print.
			fmt.Printf("GEN %d/%d [Len: Min=%d, Avg=%.3f] [CC: Max=%d, Avg=%.3f] [Fit: Min=%d, Avg=%.3f] [Diversity=%.2f] [Evals=%d] in %.2fs\n",
				generation+1, ga.params.MaxGenerations,
				mmaChromLen.MinimumInt(), mmaChromLen.Average(),
				mmaChromCC.MaximumInt(), mmaChromCC.Average(),
				mmaFitness.MinimumInt(), mmaFitness.Average(),
				ga.population.diversity(), evaluatons,
				time)
		}

		// Termination condition: did we converge to find zero?
		if ga.params.TerminateOnZero && ga.population[bestIndex].fitness == 0 {
			terminationReason = TerminationReasonZero
			ga.printf("Converged (zero): best == 0.\n")
			break
		}

		// Termination condition: is this the last generation?
		if generation+1 == ga.params.MaxGenerations {
			terminationReason = TerminationReasonMaxElapsed
			ga.printf("Converged (max): reached max generations %d.\n", ga.params.MaxGenerations)
			break
		}

		// Termination condition: did we reach a plateau?
		if len(bestTracker) >= ga.params.Plateau {
			// Get the tail in the tracker having length params.FastPlateau.
			tail := bestTracker[len(bestTracker)-ga.params.Plateau:]

			// If all the values in the tail are the same, then we have a plateau.
			foundPlateau := true
			first := tail[0]

			for i := 1; i < len(tail); i++ {
				if first != tail[i] {
					foundPlateau = false
				}
			}

			if foundPlateau {
				terminationReason = TerminationReasonPlateau
				ga.printf("Converged (plateau): best remained the same for %d generations.\n", ga.params.Plateau)
				break
			}
		}

		// Create a new population using elitism, crossover, and mutation.
		ga.population = ga.evolveNewPopulation()
	}

	// Done.
	return
}

// ---- GA HELPERS ---------------------------------------------------------

// Shuffles the order of the merges in the merge pool.
func (ga genetic) shuffleMergePool() {
	rand.Shuffle(len(ga.mergePool), func(i, j int) {
		ga.mergePool[i], ga.mergePool[j] = ga.mergePool[j], ga.mergePool[i]
	})
}

// Verbose print.
func (ga genetic) printf(format string, a ...interface{}) {
	if ga.params.Verbose {
		fmt.Printf(format, a...)
	}
}

// Checks whether the parameters seem to be valid and panics if they are not.
func (params Parameters) checkAndPanic() {
	if params.TargetSize <= 0 {
		panic("parameter TargetSize must be greater than 0")
	}

	if params.PopulationSize <= 0 {
		panic("parameter PopulationSize must be greater than 0")
	}

	if params.MaxGenerations < 1 {
		panic("parameter MaxGenerations cannot be less than 1")
	}

	if params.Plateau <= 1 {
		panic("parameter Plateau must be greater than 1")
	}

	if params.TournamentSize <= 1 {
		panic("parameter TournamentSize must be greater than 1")
	}

	if params.TournamentSize > params.PopulationSize {
		panic("parameter TournamentSize cannot be greater than parameter PopulationSize")
	}

	if params.ChromosomeLength <= 0 {
		panic("parameter ChromosomeLength must be greater than 0")
	}

	if params.MergeTableMinReduction < 0 {
		panic("parameter ReductionTableMinReduction cannot be less than 0")
	}

	if params.MergeTableMinEdsm < 0 {
		panic("parameter ReductionTableMinEdsm cannot be less than 0")
	}

	if params.MaxAttempts < 0 {
		panic("parameter MaxAttempts cannot be less than 0")
	}

	if params.CrossoverRate < 0.0 {
		panic("parameter CrossoverRate cannot be less than 0")
	}

	if params.MutationRate < 0.0 {
		panic("parameter MutationRate cannot be less than 0")
	}

	if params.EliteRate < 0.0 {
		panic("parameter EliteRate cannot be less than 0")
	}

	if params.CrossoverRate+params.EliteRate > 1.0 {
		panic("parameter (CrossoverRate + EliteRate) cannot be greater than 1")
	}

	if params.EstimatorK <= 0 {
		panic("parameter EstimatorK must be greater than 0")
	}

	if params.ResultSearchWindow < 1 {
		panic("parameter ResultSearchWindow cannot be less than 1")
	}

	if params.ResultSearchWindow > params.PopulationSize {
		panic("parameter ResultSearchWindow cannot be greater than parameter PopulationSize")
	}
}

// Returns a string representation of the parameters.
func (params Parameters) String() string {
	return fmt.Sprintf("n:%d p:%d g:%d plt:%d t0:%t tour:%d c:%d α:%d β:%d rtry:%d cross:%.2f mut:%.2f elit:%.2f eK:%d eM:%f eC:%f win:%d fast:%t",
		params.TargetSize, params.PopulationSize, params.MaxGenerations, params.Plateau, params.TerminateOnZero, params.TournamentSize,
		params.ChromosomeLength, params.MergeTableMinReduction, params.MergeTableMinEdsm, params.MaxAttempts, params.CrossoverRate,
		params.MutationRate, params.EliteRate, params.EstimatorK, params.EstimatorM, params.EstimatorC, params.ResultSearchWindow, params.UseFastEstimator)
}

// ---- DEMOS ------------------------------------------------------------------

// RunDemoGA is a demo to show how the genetic algorithm works.
func RunDemoGA() {
	// Parameters for the problem instance.
	targetSize := 32
	trainingSetSize := 607

	// *************************************************************************
	// These are the best parameters that I know of for n=32, d=64 with
	// fast estimator = true.
	// *************************************************************************
	params := Parameters{
		TargetSize:             targetSize,
		PopulationSize:         200,
		MaxGenerations:         100,
		Plateau:                25,
		TerminateOnZero:        true,
		TournamentSize:         5,
		ChromosomeLength:       8,
		MergeTableMinReduction: 25,
		MergeTableMinEdsm:      1,
		MaxAttempts:            10,
		CrossoverRate:          0.8,
		MutationRate:           0.01,
		EliteRate:              0.1,
		EstimatorK:             32,
		EstimatorM:             -0.164302668926,
		EstimatorC:             126.396466685581,
		ResultSearchWindow:     5,
		UseFastEstimator:       true,
		Concurrency:            -1,
		Verbose:                true}

	// Create a problem instance.
	target, training, _ := dfago.NewAbbadingoInstance(targetSize, true, trainingSetSize, 0)
	apta := training.APTA(target.AlphabetSize())
	colours := dfago.NewAptaTargetMap(apta, target)

	// Run.
	Run(apta, colours, params)
}
