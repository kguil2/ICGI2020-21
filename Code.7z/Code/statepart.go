// *****************************************************************************
// Kristian Guillaumier, 2017, 2021
// Represents a partitioning of states in a DFA.
// *****************************************************************************

package dfago

import (
	"fmt"
	"strconv"
	"strings"
	"time"

	"kguil.com/dfago/util"
)

// ---- TYPES ------------------------------------------------------------------

// A node in the state partition union-find.
// NOTE: if you change anything here, you'll need to update rollback and commit.
type statePartitionNode struct {
	parent int        // The pointer to the union-find parent of this node.
	back   int        // A pointer which forms a circular linked list containing all the states in the same block.
	label  StateLabel // The effective label of the block. Only valid when this is the root node. Root will be -1 if the block has mixed accepting/rejecting states.
	size   int        // The number of states in the block. Only valid when this is the root node.
	next   []int      // Transitions from this node. Note: the transitions point to the next state, NOT to the next block. When needed, this has to resolved with Find().

	// SNAPSHOT-RELATED
	dirty bool // This will be indicate whether the node has been changed.
}

// StatePartition is a partitioning of states in DFA.
type StatePartition struct {
	nodes         []statePartitionNode // The is the primary array in union find. Index is the state index, and value is the union-find node.
	numBlocks     int                  // The total number of blocks in this partition.
	numAccepting  int                  // The number of accepting blocks in this partition.
	numRejecting  int                  // The number of rejecting blocks in this partition.
	alphabetSize  int                  // The size of the alphabet of the partitioned DFA.
	startingState int                  // The starting state of the partitioned DFA.

	// SNAPSHOT-RELATED
	snapshot     bool  // Whether the partition is in snapshot mode or not.
	changedCount int   // The number of nodes changed.
	changedNodes []int // The indices of the nodes changed [0...changedCount).
}

// ---- CONSTRUCTION -----------------------------------------------------------

// StatePartition returns an initial partitionining of the states in a DFA where
// every state is in its own block.
func (dfa DFA) StatePartition() StatePartition {

	// Prepare the result.
	result := StatePartition{
		nodes:         make([]statePartitionNode, len(dfa.States)),
		numBlocks:     len(dfa.States),
		numAccepting:  0,
		numRejecting:  0,
		alphabetSize:  len(dfa.Alphabet),
		startingState: dfa.StartingState,
		snapshot:      false,
		changedCount:  0,
		changedNodes:  make([]int, len(dfa.States))}

	// Put each state in its own block.
	for i := 0; i < len(dfa.States); i++ {

		// Create the node.
		result.nodes[i] = statePartitionNode{
			parent: i,
			back:   i,
			label:  dfa.States[i].Label,
			size:   1,
			next:   make([]int, dfa.AlphabetSize()),
			dirty:  false}

		// Copy the next pointers.
		copy(result.nodes[i].next, dfa.States[i].Next)

		// Number of labelled states in this block.
		if dfa.States[i].Label == Accepting {
			result.numAccepting++
		} else if dfa.States[i].Label == Rejecting {
			result.numRejecting++
		}
	}

	// Done.
	return result
}

// ---- FUNCTIONS --------------------------------------------------------------

// AlphabetSize returns the alphabet size over which this partition is defined.
func (part StatePartition) AlphabetSize() int {
	return part.alphabetSize
}

// NumStates returns the number of states stored in this partition.
func (part StatePartition) NumStates() int {
	return len(part.nodes)
}

// NumBlocks returns the number of blocks in this partition.
func (part StatePartition) NumBlocks() int {
	return part.numBlocks
}

// NumAcceptingBlocks returns the number of accepting blocks in this partition.
func (part StatePartition) NumAcceptingBlocks() int {
	return part.numAccepting
}

// NumRejectingBlocks returns the number of rejecting blocks in this partition.
func (part StatePartition) NumRejectingBlocks() int {
	return part.numRejecting
}

// NumLabelledBlocks returns the number of labelled blocks in this partition.
func (part StatePartition) NumLabelledBlocks() int {
	return part.numAccepting + part.numRejecting
}

// NumUnlabelledBlocks returns the number of ulabelled blocks in this partition.
func (part StatePartition) NumUnlabelledBlocks() int {
	return part.numBlocks - (part.numAccepting + part.numRejecting)
}

// StartingBlock returns the starting block (state) in the quotient automaton
// that this partition represents.
func (part *StatePartition) StartingBlock() int {
	return part.Find(part.startingState)
}

// Blocks returns a list of blocks in the partition.
func (part StatePartition) Blocks() (blocks []int) {
	blocks = make([]int, part.numBlocks)
	index := 0

	// A state index is a block (root) if its parent is itself.
	for i := range part.nodes {
		if part.nodes[i].parent == i {
			blocks[index] = i
			index++
		}
	}
	return
}

// OrderedBlocks returns a list of blocks in the partition in canonical order
// of the quotient automaton that this partition represents.
func (part *StatePartition) OrderedBlocks() []int {
	// Do breadth-first search to get the order. Prepare the queue.
	start := part.Find(part.startingState)
	queue := util.NewIntQueueWithValueAndCapacity(start, part.numBlocks)
	visit := util.NewIntSetWithValueAndCapacity(start, part.numBlocks)

	// Put out result here.
	order := make([]int, 0, part.numBlocks)

	// Do the BFS.
	for queue.NotEmpty() {
		// Dequeue.
		current, _ := queue.Dequeue()

		// Visit and add to result.
		order = append(order, current)

		// Visit all the transitions from this block.
		for symbol := 0; symbol < part.alphabetSize; symbol++ {
			if next := part.nodes[current].next[symbol]; next >= 0 {
				// Note that this is the next state, not necessarily next block
				// so we have to fix it.
				next = part.Find(next)

				// Only enqueue if not visited.
				if !visit.Contains(next) {
					visit.Add(next)
					queue.Enqueue(next)
				}
			}
		}
	}

	// If we didn't visit all the blocks, the quotient has unreachable states.
	if len(order) != part.numBlocks {
		panic("the partition has unreachable blocks")
	}

	// Done.
	return order
}

// BlockSize returns the number of states in the block which contains the
// given state.
func (part *StatePartition) BlockSize(anyStateIndex int) int {
	return part.nodes[part.Find(anyStateIndex)].size
}

// BlockLabel returns the label of the block which contains the given state.
// Will return -1 if the block contains mixed accepting and rejecting label.
// This may be caused by a union but not a detmerge operation.
func (part *StatePartition) BlockLabel(anyStateIndex int) StateLabel {
	return part.nodes[part.Find(anyStateIndex)].label
}

// StatesInBlock returns a list of all the states in the block idendified
// by any member of the block.
func (part StatePartition) StatesInBlock(anyStateIndex int) (states []int) {
	// Prepare the result starting from the first state.
	start := anyStateIndex
	states = []int{start}

	// Add the rest by following the back pointer.
	for part.nodes[anyStateIndex].back != start {
		anyStateIndex = part.nodes[anyStateIndex].back
		states = append(states, anyStateIndex)
	}
	return
}

// Succ returns the index of the next (successor) block from the block
// containing the given state index for a symbol. Will return -1 if no
// transition is defined from the given block and symbol.
func (part *StatePartition) Succ(anyStateIndex, symbol int) (next int) {
	next = part.nodes[part.Find(anyStateIndex)].next[symbol]

	// If there is a next state, resolve it to the block - remember that the
	// next array does not store blocks but state indices that need to be
	// resolved.
	if next >= 0 {
		next = part.Find(next)
	}
	return
}

// SmallestStateInBlock returns the smallest index the states in a block
// identified by any member of it.
func (part StatePartition) SmallestStateInBlock(anyStateIndex int) int {
	start := anyStateIndex
	smallest := anyStateIndex

	// Loop around.
	for part.nodes[anyStateIndex].back != start {
		anyStateIndex = part.nodes[anyStateIndex].back

		if anyStateIndex < smallest {
			smallest = anyStateIndex
		}
	}

	// Done.
	return smallest
}

// Deterministic determines whether the quotient automaton represented by this
// partition represents a determinisic automaton.
func (part *StatePartition) Deterministic() bool {
	// Get the blocks.
	blocks := part.Blocks()

	// Check if a block is non-determinisic.
	for _, blockIndex := range blocks {
		// Examine all the states in the blocks.
		states := part.StatesInBlock(blockIndex)

		for symbol := 0; symbol < part.alphabetSize; symbol++ {
			first := -1

			for _, stateIndex := range states {
				if next := part.nodes[stateIndex].next[symbol]; next >= 0 {
					if first == -1 {
						first = part.Find(next)
					} else {
						if first != part.Find(next) {
							return false
						}
					}
				}
			}
		}
	}

	// All OK.
	return true
}

// Clone returns an exact copy of this instance.
func (part StatePartition) Clone() StatePartition {
	// Make a copy.
	result := StatePartition{
		nodes:         make([]statePartitionNode, len(part.nodes)),
		numBlocks:     part.numBlocks,
		numAccepting:  part.numAccepting,
		numRejecting:  part.numRejecting,
		alphabetSize:  part.alphabetSize,
		startingState: part.startingState,
		snapshot:      part.snapshot,
		changedCount:  part.changedCount,
		changedNodes:  make([]int, len(part.changedNodes))}

	// Copy the slices over.
	copy(result.nodes, part.nodes)

	// Deep copy the transitions.
	for i := range part.nodes {
		result.nodes[i].next = make([]int, len(part.nodes[i].next))
		copy(result.nodes[i].next, part.nodes[i].next)
	}

	// Copy the changed nodes.
	copy(result.changedNodes, part.changedNodes)

	// Done.
	return result
}

// Equal determines whether two partitions are exactly the same.
func (part StatePartition) Equal(other StatePartition) bool {
	// First check the basic stuff.
	if !(part.numBlocks == other.numBlocks &&
		part.numAccepting == other.numAccepting &&
		part.numRejecting == other.numRejecting &&
		part.alphabetSize == other.alphabetSize &&
		part.startingState == other.startingState &&
		part.snapshot == other.snapshot &&
		part.changedCount == other.changedCount &&
		len(part.nodes) == len(other.nodes) &&
		len(part.changedNodes) == len(other.changedNodes)) {
		return false
	}

	// Check the changed nodes (only bother up to the changed count).
	for i := 0; i < part.changedCount; i++ {
		if part.changedNodes[i] != other.changedNodes[i] {
			return false
		}
	}

	// Check that the nodes are the same.
	for i := 0; i < len(part.nodes); i++ {
		if !(part.nodes[i].parent == other.nodes[i].parent &&
			part.nodes[i].back == other.nodes[i].back &&
			part.nodes[i].label == other.nodes[i].label &&
			part.nodes[i].size == other.nodes[i].size &&
			part.nodes[i].dirty == other.nodes[i].dirty) {
			return false
		}

		// Check the next pointers.
		for j, v := range part.nodes[i].next {
			if other.nodes[i].next[j] != v {

				return false
			}
		}
	}

	// All OK.
	return true
}

// Fingerprint returns a string that uniquely identifies this partition
// irrespective of how the blocks are ordered and how the states within them
// are ordered.
// i.e. {{3,1},{2},{6,4,5}} == {{1,3},{2},{4,5,6}} == {{2},{3,1},{4,5,6}}
func (part StatePartition) Fingerprint() string {
	// The finger print will be: a list as long as the number of states in the
	// partition, where every element will be the index of the smallest state
	// in the block of the state at that position.
	arr := make([]string, len(part.nodes))

	for i := 0; i < len(part.nodes); i++ {
		arr[i] = strconv.Itoa(part.SmallestStateInBlock(i))
	}

	// Done.
	return strings.Join(arr, ",")
}

// ---- QUOTIENT DFA -----------------------------------------------------------

// MappedQuotientDFA returns a quotient DFA from the current partition with
// respet to the DFA from which we originally created the partition as well as
// a slice where the index corresponds to the state index in the quotient DFA
// just created and the value is the corresponding block in this partition.
//
// NOTE: This function will panic if there are mixed-label blocks in the
//       partition (which is possible after a union but not a detmerge) or if
//       the quotient is non-deterministic.
//
func (part *StatePartition) MappedQuotientDFA() (DFA, []int) {
	// Get all the blocks.
	blocks := part.Blocks()

	// Map a state to a block.
	stateToBlock := make([]int, len(blocks))

	// Map a block to a state.
	blockToState := make(map[int]int, len(blocks))

	// Create the resulting DFA.
	result := NewSizedDFA(part.alphabetSize, len(blocks))

	// Create one state per block.
	for _, blockIndex := range blocks {
		// Check if the block has mixed labellings.
		if part.nodes[blockIndex].label < 0 {
			panic("a block in this partition has mixed labels")
		}

		// Get the label of the block.
		label := part.nodes[blockIndex].label

		// Create the state in the new DFA.
		stateIndex := result.AddState(label)

		// Add to the maps.
		stateToBlock[stateIndex] = blockIndex
		blockToState[blockIndex] = stateIndex
	}

	// Now create the transitions.
	for symbol := 0; symbol < part.alphabetSize; symbol++ {
		for stateIndex := range result.States {
			blockIndex := stateToBlock[stateIndex]

			if next := part.nodes[blockIndex].next[symbol]; next >= 0 {
				// Remember that next points to a node not a block. Resolve.
				next = part.Find(next)

				// Get the adjacent state in the new DFA.
				nextState := blockToState[next]

				// Create tehe transition but first check if it already exists
				// in the result.
				if result.States[stateIndex].Next[symbol] < 0 {
					result.AddTransition(stateIndex, nextState, symbol)
				} else if result.States[stateIndex].Next[symbol] != nextState {
					panic("the quotient DFA is non-deterministic")
				}
			}
		}
	}

	// Set the starting state.
	result.StartingState = blockToState[part.Find(part.startingState)]

	// Done.
	return result, stateToBlock
}

// QuotientDFA returns a quotient DFA from the current partition with respect
// to the DFA from which we originally created the partition.
//
// NOTE: This function will panic if there are mixed-label blocks in the
//       partition or if the quotient is non-deterministic.
//
func (part *StatePartition) QuotientDFA() DFA {
	quotient, _ := part.MappedQuotientDFA()
	return quotient
}

// ---- UNION-FIND RELATED -----------------------------------------------------

// Find returns the block to which the given state belongs to. This is the
// "find" operation of union-find.
func (part *StatePartition) Find(anyStateIndex int) int {
	// Path compression using path halving.
	// See https://en.wikipedia.org/wiki/Disjoint-set_data_structure
	if part.snapshot {
		for part.nodes[anyStateIndex].parent != anyStateIndex {
			part.markDirty(anyStateIndex)
			part.nodes[anyStateIndex].parent = part.nodes[part.nodes[anyStateIndex].parent].parent
			anyStateIndex = part.nodes[anyStateIndex].parent
		}
	} else {
		for part.nodes[anyStateIndex].parent != anyStateIndex {
			part.nodes[anyStateIndex].parent = part.nodes[part.nodes[anyStateIndex].parent].parent
			anyStateIndex = part.nodes[anyStateIndex].parent
		}
	}

	// Done.
	return anyStateIndex
}

// Union joins two blocks together identified by any two states belonging to
// the blocks.
//
// Note: A join may result in a block containing mixed accepting and
//       rejecting labels. If neccessary, use the BlockHasMixedLabels() function
//       to check for this.
//
// !!! ANY CHANGES MADE HERE MUST BE SYNCED WITH DetMerge() DUE TO MANUAL INLINE.
//
func (part *StatePartition) Union(anyStateIndex1, anyStateIndex2 int) int {
	// Resolve the states to their blocks/roots.
	anyStateIndex1 = part.Find(anyStateIndex1)
	anyStateIndex2 = part.Find(anyStateIndex2)

	// If both states are in the same block, there's nothing to do.
	if anyStateIndex1 == anyStateIndex2 {
		return anyStateIndex1
	}

	// Merge smaller block into the larger one (union by rank/size).
	if part.nodes[anyStateIndex1].size < part.nodes[anyStateIndex2].size {
		anyStateIndex1, anyStateIndex2 = anyStateIndex2, anyStateIndex1
	}

	// Log all changes if in snapshot mode.
	if part.snapshot {
		part.markDirty(anyStateIndex1)
		part.markDirty(anyStateIndex2)
	}

	// Pointers to parent and child.
	parent, child := &part.nodes[anyStateIndex1], &part.nodes[anyStateIndex2]

	// A block will be 'deleted' by the union.
	part.numBlocks--

	// Correct the number of labelled blocks in the partition.
	if parent.label == Accepting && child.label == Accepting {
		part.numAccepting--
	} else if parent.label == Rejecting && child.label == Rejecting {
		part.numRejecting--
	}

	// Resolve the label of the parent after the union.
	if parent.label == Unlabelled {
		parent.label = child.label
	} else if parent.label != child.label && child.label != Unlabelled {
		parent.label = -1
	}

	// The size of the block will increase.
	parent.size += child.size

	// Correct the transitions.
	for symbol := 0; symbol < part.alphabetSize; symbol++ {
		// If the parent has no transition for the symbol, inherit it from the child.
		if parent.next[symbol] == -1 {
			parent.next[symbol] = child.next[symbol]
		}
	}

	// Make the child point to the parent.
	child.parent = anyStateIndex1
	parent.back, child.back = child.back, parent.back

	// Done.
	return anyStateIndex1
}

// ---- UNDO RELATED -----------------------------------------------------------

// Marks a block in a snapshot as dirty by flagging it and adding it to the
// rollback or commit list. This function will panic if this partition is not a
// snapshot.
func (part *StatePartition) markDirty(stateIndex int) {
	if !part.snapshot {
		panic("this partition is not a snapshot")
	}

	// It is important to only do this if the state is not already marked as
	// dirty so that we don't undo it twice.
	if !part.nodes[stateIndex].dirty {
		part.changedNodes[part.changedCount] = stateIndex
		part.changedCount++
		part.nodes[stateIndex].dirty = true
	}
}

// Snapshot returns an exact copy of this partition in snapshot mode. Changes
// made in a snapshot can either be committed or rolled back.
func (part StatePartition) Snapshot() StatePartition {
	// Check.
	if part.snapshot {
		panic("this partition is already a snapshot")
	}

	// Make a copy.
	result := part.Clone()

	// Mark it as a snapshot.
	result.snapshot = true
	result.changedCount = 0

	// Done.
	return result
}

// RollbackFrom writes back all the changes made to this snapshot **FROM** the
// reference partition and clears the change log. This function will panic if
// this partition is not a snapshot.
func (part *StatePartition) RollbackFrom(referencePartition StatePartition) {
	// Check.
	if !part.snapshot {
		panic("this partition is not a snapshot")
	}

	if referencePartition.snapshot {
		panic("the reference partition is a snapshot")
	}

	// Rewrite the original values.
	part.numBlocks = referencePartition.numBlocks
	part.numAccepting = referencePartition.numAccepting
	part.numRejecting = referencePartition.numRejecting

	// Go thru the changed nodes and write them back.
	for _, stateID := range part.changedNodes[:part.changedCount] {
		dst := &part.nodes[stateID]
		src := &referencePartition.nodes[stateID]

		dst.parent = src.parent
		dst.back = src.back
		dst.label = src.label
		dst.size = src.size
		// dst.colour = src.colour
		dst.dirty = src.dirty

		copy(dst.next, src.next)
	}

	// Reset changes.
	part.changedCount = 0
}

// CommitTo writes all the changes made in this snapshot **TO** the
// reference partition and clears the change log. This function will panic if
// this partition is not a snapshot.
func (part *StatePartition) CommitTo(referencePartition *StatePartition) {
	// Check.
	if !part.snapshot {
		panic("this partition is not a snapshot")
	}

	if referencePartition.snapshot {
		panic("the reference partition is a snapshot")
	}

	// Rewrite the values back.
	referencePartition.numBlocks = part.numBlocks
	referencePartition.numAccepting = part.numAccepting
	referencePartition.numRejecting = part.numRejecting

	// Go thru the changed nodes and write them back.
	for _, stateID := range part.changedNodes[:part.changedCount] {
		// The node is no longer dirty.
		part.nodes[stateID].dirty = false

		// Copy over.
		dst := &referencePartition.nodes[stateID]
		src := &part.nodes[stateID]

		dst.parent = src.parent
		dst.back = src.back
		dst.label = src.label
		dst.size = src.size
		dst.dirty = src.dirty

		copy(dst.next, src.next)
	}

	// Reset changes.
	part.changedCount = 0
}

// ---- COLOUR-COMPATIBILITY ---------------------------------------------------

// BlockColourCompatible determines whether all the states in a block identified
// by any state that it contains are colour-compatible.
func (part StatePartition) BlockColourCompatible(anyStateIndex int, colours AptaTargetMap) bool {
	start := anyStateIndex
	startColour := colours[anyStateIndex]

	for part.nodes[anyStateIndex].back != start {
		anyStateIndex = part.nodes[anyStateIndex].back

		if colours[anyStateIndex] != startColour {
			return false
		}
	}
	return true
}

// ColourCompatible determines whether all the blocks in the partion are
// colour-compatible with respect to a target map.
func (part StatePartition) ColourCompatible(colours AptaTargetMap) bool {
	// Loop thru all the blocks.
	for blockIndex := 0; blockIndex < len(part.nodes); blockIndex++ {
		if part.nodes[blockIndex].parent == blockIndex && part.nodes[blockIndex].size > 1 {
			// We are in a block.
			stateIndex := blockIndex
			startColour := colours[blockIndex]

			// Make sure that all the states in the block have the same colour.
			for part.nodes[stateIndex].back != blockIndex {
				stateIndex = part.nodes[stateIndex].back
				if colours[stateIndex] != startColour {
					return false
				}
			}
		}
	}
	return true
}

// ---- SERIALISE AND DESERIALISE  ---------------------------------------------

// Serialise converts this instance to an object that can be serialised.
func (part StatePartition) Serialise() SerialiseObject {
	// Prepare the nodes.
	nodes := make([]map[string]interface{}, len(part.nodes))

	for i, node := range part.nodes {
		// Add to the node to the list.
		nodes[i] = map[string]interface{}{
			"parent": node.parent,
			"back":   node.back,
			"label":  node.label,
			"size":   node.size,
			"next":   node.next,
			"dirty":  node.dirty}
	}

	// Done.
	return SerialiseObject{
		"docType":       "DfaGo/StatePartition",
		"version":       1.0,
		"dateCreated":   time.Now().Format(time.RFC3339),
		"nodes":         nodes,
		"numBlocks":     part.numBlocks,
		"numAccepting":  part.numAccepting,
		"numRejecting":  part.numRejecting,
		"alphabetSize":  part.alphabetSize,
		"startingState": part.startingState,
		"snapshot":      part.snapshot,
		"changedCount":  part.changedCount,
		"changedNodes":  part.changedNodes}
}

// Deserialises a serialised object to an instance.
func DeserialiseStatePartition(data DeserialiseObject) StatePartition {
	// Validate the doc type and version.
	if expected, got := 1.0, data["version"].(float64); expected != got {
		panic(fmt.Sprintf("JSON file has an unsupported version, expected:%f, got:%f", expected, got))
	}

	if expected, got := "DfaGo/StatePartition", data["docType"].(string); expected != got {
		panic(fmt.Sprintf("JSON file has an unsupported doc type, expected:%s, got:%s", expected, got))
	}

	// Start building the result.
	result := StatePartition{
		numBlocks:     int(data["numBlocks"].(float64)),
		numAccepting:  int(data["numAccepting"].(float64)),
		numRejecting:  int(data["numRejecting"].(float64)),
		alphabetSize:  int(data["alphabetSize"].(float64)),
		startingState: int(data["startingState"].(float64)),
		snapshot:      data["snapshot"].(bool),
		changedCount:  int(data["changedCount"].(float64))}

	// Read the nodes.
	nodes := data["nodes"].([]interface{})
	result.nodes = make([]statePartitionNode, len(nodes))

	for i, v := range nodes {
		node := v.(map[string]interface{})

		result.nodes[i] = statePartitionNode{
			parent: int(node["parent"].(float64)),
			back:   int(node["back"].(float64)),
			label:  StateLabel(node["label"].(float64)),
			size:   int(node["size"].(float64)),
			dirty:  node["dirty"].(bool)}

		next := node["next"].([]interface{})
		result.nodes[i].next = make([]int, len(next))

		for j, w := range next {
			result.nodes[i].next[j] = int(w.(float64))
		}
	}

	// Read the changed nodes.
	changedNodes := data["changedNodes"].([]interface{})
	result.changedNodes = make([]int, len(changedNodes))

	for i, v := range changedNodes {
		result.changedNodes[i] = int(v.(float64))
	}

	// Done.
	return result
}
